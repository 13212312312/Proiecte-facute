#include "face.h"
#include <bits/stdc++.h>
using namespace std;

void face::setValue(int x)
{
    int i,j;
    for(i=1;i<=3;i++)
        for(j=1;j<=3;j++)
    {
        this->value[i][j]=x;
    }
}
void face::setName(int x)
{
    this->name=x;
}
void face::Print()
{
    int i,j;
    for(i=1;i<=3;i++)
        {
        for(j=1;j<=3;j++)
            cout<<this->value[i][j]<<" ";
        cout<<'\n';
        }
    cout<<"\n\n";
}
int face::getValue(int i,int j)
{
    return this->value[i][j];
}

void face::setValue(int i,int j,int val)
{
    this->value[i][j]=val;
}
void face::rotation(int nr)
{
    int i,j;
    face aux,aux2;
    while(nr>0)
    {
        nr--;
        for(i=1;i<=3;i++)
            for(j=1;j<=3;j++)
                aux.setValue(j,i,this->getValue(i,j));
        for(i=1;i<=3;i++)
            for(j=1;j<=3;j++)
                aux2.setValue(3-i+1,j,aux.getValue(i,j));
        for(i=1;i<=3;i++)
            for(j=1;j<=3;j++)
                this->setValue(i,j,aux2.getValue(i,j));
    }
}
void face::operator=(face b)
{
    int i,j;
    for(i=1;i<=3;i++)
    {
        for(j=1;j<=3;j++)
        {
            this->value[i][j]=b.getValue(i,j);
        }
    }
}
bool face::operator==(face b)
{
    int i,j,nr,ok;
    nr=4;
    while(nr>0)
    {
        ok = 1;
        for(i=1;i<=3;i++)
            for(j=1;j<=3;j++)

                if(b.getValue(i,j)!=this->value[i][j]) ok=0;
        if(ok) return true;
        nr--;
        b.rotation();
    }
    return false;
}
/**bool face::operator==(face b)
{
    int i,j,nr,ok;
    ok=1;
    for(i=1;i<=3;i++)
    {
        for(j=1;j<=3;j++)
        {
            if(this->getValue(i,j)!=7&&b.getValue(i,j)!=7)
            {
                if(this->getValue(i,j)!=b.getValue(i,j))
                    ok=0;
            }
        }
    }
    if(ok==1)
        return true;
    return false;
}*/
