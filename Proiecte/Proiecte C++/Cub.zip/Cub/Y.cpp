#include "Y.h"
using namespace std;
string Y::print()
{
    return "Y";
}
string y::print()
{
    return "Y\'";
}
string Y::ReversePrint()
{
    return "Y\'";
}
string y::ReversePrint()
{
    return "Y";
}
void y::Execute(cube &cub)
{
    face aux,aux2;
    aux=cub.getFace(FRONT);
    aux2=cub.getFace(LEFT);
    cub.setFace(aux,LEFT);
    aux=aux2;
    aux2=cub.getFace(BACK);
    cub.setFace(aux,BACK);
    aux=aux2;
    aux2=cub.getFace(RIGHT);
    cub.setFace(aux,RIGHT);
    cub.setFace(aux2,FRONT);
    aux=cub.getFace(UP);
    aux.rotation(3);
    cub.setFace(aux,UP);
    aux=cub.getFace(DOWN);
    aux.rotation();
    cub.setFace(aux,DOWN);
}
void Y::Execute(cube &cub)
{
    face aux,aux2;
    aux=cub.getFace(FRONT);
    aux2=cub.getFace(RIGHT);
    cub.setFace(aux,RIGHT);
    aux=aux2;
    aux2=cub.getFace(BACK);
    cub.setFace(aux,BACK);
    aux=aux2;
    aux2=cub.getFace(LEFT);
    cub.setFace(aux,LEFT);
    cub.setFace(aux2,FRONT);
    aux=cub.getFace(UP);
    aux.rotation();
    cub.setFace(aux,UP);
    aux=cub.getFace(DOWN);
    aux.rotation(3);
    cub.setFace(aux,DOWN);
}
