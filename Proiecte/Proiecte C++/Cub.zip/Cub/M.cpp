#include "M.h"
using namespace std;
string M::print()
{
    return "M";
}
string m::print()
{
    return "M\'";
}
string M::ReversePrint()
{
    return "M\'";
}
string m::ReversePrint()
{
    return "M";
}
void M::Execute(cube &cub)
{
    vector<int> aux,aux2;
    aux=cub.getColumn(UP,2);
    aux2=cub.getColumn(FRONT,2);
    cub.setColumn(FRONT,2,aux);
    aux=aux2;
    aux2=cub.getColumn(DOWN,2);
    cub.setColumn(DOWN,2,aux);
    aux=aux2;
    aux2=cub.getColumn(BACK,2);
    reverse(aux.begin(),aux.end());
    cub.setColumn(BACK,2,aux);
    reverse(aux2.begin(),aux2.end());
    cub.setColumn(UP,2,aux2);
}
void m::Execute(cube &cub)
{
    vector<int> aux,aux2;
    aux=cub.getColumn(UP,2);
    aux2=cub.getColumn(BACK,2);
    reverse(aux.begin(),aux.end());
    cub.setColumn(BACK,2,aux);
    aux=aux2;
    aux2=cub.getColumn(DOWN,2);
    reverse(aux.begin(),aux.end());
    cub.setColumn(DOWN,2,aux);
    aux=aux2;
    aux2=cub.getColumn(FRONT,2);
    cub.setColumn(FRONT,2,aux);
    cub.setColumn(UP,2,aux2);
}
