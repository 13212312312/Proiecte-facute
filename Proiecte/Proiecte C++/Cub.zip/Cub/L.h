#pragma once
#include "mutare.h"
using namespace std;
class L : public mutare
{
public:
    string print();
    void Execute(cube &x);
    string ReversePrint();
};
class l : public mutare
{
public:
    string print();
    void Execute(cube &x);
    string ReversePrint();
};
