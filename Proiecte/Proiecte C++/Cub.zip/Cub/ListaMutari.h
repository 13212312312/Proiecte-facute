#pragma once
#include <bits/stdc++.h>
using namespace std;
struct algm{
    string Algorithm;
    string Name;
};

class ListaMutari
{
    string str[36];
    int NoRotation;
    int nrAlg;
    vector<int> Recomandari = { 6,8,9,11,12,14,16,17,19,22,25,30,31,33,36,38,43,46,47,50,53,58,71,73,81,89,91,92 };
    algm AlgorithmList[1001];
public:
    ListaMutari();
    string repairString(string v);
    string fixString(string v);
    void mutari();
    void LoadAlgorithm();
    string GenerateMoves();
    void afisareMutari();
    int getnrAlg();
    int getNoRotation();
    vector<int> getRecomandari();
    string getString(int poz);
    algm getAlgorithm(int poz);
    string repositionString(string v);
    int numberOfLetters(string v);
    int numberOfCharacters(string v);
};
