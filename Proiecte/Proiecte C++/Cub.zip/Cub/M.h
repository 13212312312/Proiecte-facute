#pragma once
#include "mutare.h"
using namespace std;
class M : public mutare
{
public:
    string print();
    void Execute(cube &cub);
    string ReversePrint();
};
class m : public mutare
{
public:
    string print();
    void Execute(cube &cub);
    string ReversePrint();
};

