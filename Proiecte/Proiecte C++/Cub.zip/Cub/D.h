#include "mutare.h"
using namespace std;
class D : public mutare
{
public:
    string print();
    void Execute(cube &x);
    string ReversePrint();
};
class d : public mutare
{
public:
    string print();
    void Execute(cube &x);
    string ReversePrint();
};
