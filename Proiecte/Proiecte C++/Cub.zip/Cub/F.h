#include "mutare.h"
using namespace std;
class F : public mutare
{
public:
    string print();
    void Execute(cube &x);
    string ReversePrint();
};
class f : public mutare
{
public:
    string print();
    void Execute(cube &x);
    string ReversePrint();
};
