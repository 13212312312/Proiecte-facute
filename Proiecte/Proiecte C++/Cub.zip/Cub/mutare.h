#pragma once
#include <bits/stdc++.h>
#include "cube.h"
#define UP 1
#define DOWN 2
#define LEFT 3
#define FRONT 4
#define RIGHT 5
#define BACK 6
class cube;
using namespace std;
class mutare
{
public:
    mutare(){};
    virtual void Execute(cube &x) = 0;
    virtual string print() = 0;
    virtual string ReversePrint() = 0;
};
