#pragma once
#include <bits/stdc++.h>
#include <graphics.h>
#include <winbgim.h>
#include "mutare.h"
#include "face.h"
using namespace std;
extern int stopthread;
class mutare;
class cube
{
    int firstWindow;
    int secondWindow;
    string alg;
    face fete[7];
    mutare* mutari[10001];
    int NumberOfMoves;
    int finished;
    int option;
    int curent;
    string finalSolution;
    string *ListOfMoves;
    int solved;
    int cnt;
    int nraplicari;
public:
    cube();
    void Print();
    void printAlgoritm(ostream& out = cout,int index = -1,int z = -1,int t = -1);
    void setMoves(string v);
    vector<int> getRow(int face,int row);
    int getValue(int face,int x,int y);
    vector<int> getColumn(int face,int column);
    void setRow(int face,int row,vector<int> v);
    void setColumn(int face,int column,vector<int> v);
    void Draw(int nr = 1,int pas = 0,int solving = 0);
    void DrawCube(int numar = 1,int solving = 0,int index = -1);
    void DrawOption(int nr = 0);
    int getNumberOfMoves();
    int getFinishedState();
    void transfer(cube a);
    int getOption();
    cube rotateCube();
    int verif();
    string getFinalSolution();
    string getListOfMoves(int i);
    std::thread getThread();
    int getnraplicari();
    bool operator==(cube b);
    void operator=(cube b);
    void executeMove(string x);
    int getCount();
    mutare* getMutare(int i);
    int howMany(ostream& out = cout,int index = -1,int x = -1,int y = -1);
    face getFace(int i);
    void setFace(face x,int i);
    void Execute(int nr = 1,int desen = 0,int numar = 1,int solving = 0);
    void Compare(cube y,ostream& out = cout);
    void setSolvedState(int state);
    int getSolvedState();
    void backtracking();
    std::thread Solve1();
    void Solve2();
    string getSolution();
    string Solve(int state = 1,ostream& out = cout);
    void SolveAndDraw(int option);
    void printSolveData(ostream& out = cout);
    void changeString(int index);
    void drawChangeStringMeniu(int aux);
    int checkMove(int x,int y,int where);
    int ApplyOption(int option,int here,int poz=-1);
};
