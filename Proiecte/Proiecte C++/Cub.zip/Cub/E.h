#pragma once
#include "mutare.h"
using namespace std;
class E : public mutare
{
public:
    string print();
    void Execute(cube &cub);
    string ReversePrint();
};
class e : public mutare
{
public:
    string print();
    void Execute(cube &cub);
    string ReversePrint();
};


