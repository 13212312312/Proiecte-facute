#include "Z.h"
using namespace std;
string Z::print()
{
    return "Z";
}
string z::print()
{
    return "Z\'";
}
string Z::ReversePrint()
{
    return "Z\'";
}
string z::ReversePrint()
{
    return "Z";
}
void Z::Execute(cube &cub)
{
    face aux,aux2;
    aux=cub.getFace(UP);
    aux2=cub.getFace(RIGHT);
    aux.rotation(3);
    cub.setFace(aux,RIGHT);
    aux=aux2;
    aux2=cub.getFace(DOWN);
    aux.rotation(3);
    cub.setFace(aux,DOWN);
    aux=aux2;
    aux2=cub.getFace(LEFT);
    aux.rotation(3);
    cub.setFace(aux,LEFT);
    aux2.rotation(3);
    cub.setFace(aux2,UP);
    aux=cub.getFace(FRONT);
    aux.rotation(3);
    cub.setFace(aux,FRONT);
    aux=cub.getFace(BACK);
    aux.rotation();
    cub.setFace(aux,BACK);
}
void z::Execute(cube &cub)
{
    face aux,aux2;
    aux=cub.getFace(UP);
    aux2=cub.getFace(LEFT);
    aux.rotation();
    cub.setFace(aux,LEFT);
    aux=aux2;
    aux2=cub.getFace(DOWN);
    aux.rotation();
    cub.setFace(aux,DOWN);
    aux=aux2;
    aux2=cub.getFace(RIGHT);
    aux.rotation();
    cub.setFace(aux,RIGHT);
    aux2.rotation();
    cub.setFace(aux2,UP);
    aux=cub.getFace(FRONT);
    aux.rotation();
    cub.setFace(aux,FRONT);
    aux=cub.getFace(BACK);
    aux.rotation(3);
    cub.setFace(aux,BACK);
}
