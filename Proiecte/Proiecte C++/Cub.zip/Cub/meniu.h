#pragma once
#include <bits/stdc++.h>
#include "cube.h"
#include "ListaMutari.h"
using namespace std;

class MainMenu
{
    string aux;
    ListaMutari Moves;
public:
    void meniuPrincipal();
    string meniu();
    int pascupas();
};
