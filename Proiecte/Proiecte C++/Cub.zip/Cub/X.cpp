#include "X.h"
using namespace std;
string X::print()
{
    return "X";
}
string x::print()
{
    return "X\'";
}
string X::ReversePrint()
{
    return "X\'";
}
string x::ReversePrint()
{
    return "X";
}
void X::Execute(cube &cub)
{
    face aux,aux2;
    aux=cub.getFace(FRONT);
    aux2=cub.getFace(UP);
    cub.setFace(aux,UP);
    aux=aux2;
    aux2=cub.getFace(BACK);
    aux.rotation(2);
    cub.setFace(aux,BACK);
    aux=aux2;
    aux2=cub.getFace(DOWN);
    aux.rotation(2);
    cub.setFace(aux,DOWN);
    cub.setFace(aux2,FRONT);
    aux=cub.getFace(LEFT);
    aux.rotation();
    cub.setFace(aux,LEFT);
    aux=cub.getFace(RIGHT);
    aux.rotation(3);
    cub.setFace(aux,RIGHT);

}
void x::Execute(cube &cub)
{
    face aux,aux2;
    aux=cub.getFace(FRONT);
    aux2=cub.getFace(DOWN);
    cub.setFace(aux,DOWN);
    aux=aux2;
    aux2=cub.getFace(BACK);
    aux.rotation(2);
    cub.setFace(aux,BACK);
    aux=aux2;
    aux2=cub.getFace(UP);
    aux.rotation(2);
    cub.setFace(aux,UP);
    cub.setFace(aux2,FRONT);
    aux=cub.getFace(LEFT);
    aux.rotation(3);
    cub.setFace(aux,LEFT);
    aux=cub.getFace(RIGHT);
    aux.rotation();
    cub.setFace(aux,RIGHT);

}
