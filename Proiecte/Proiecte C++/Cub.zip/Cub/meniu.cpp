#include "meniu.h"
void MainMenu::meniuPrincipal()
{
    srand(time(NULL));
    string alg,solution;
    std::thread t1;
    cube x,y;
    alg=meniu();
    x.setMoves(alg);
    x.SolveAndDraw(pascupas());
}
string MainMenu::meniu()
{
    int optiune,choose,i;
    char s[101];
    cout<<"Doriti: \n(1)sa introduceti un algoritm;\n(2)sa se genereze unul aleatoriu;\n(3)sa se execute cel predefinit;\n";
    cin>>optiune;
    string alg;
    if(optiune==1)
    {
        cin.getline(s,101);
        Moves.afisareMutari();
        cout<<"Introduceti algoritmul: \n";
        cin.getline(s,101);
        alg=s;
    }
    else
    {
        if(optiune==2)
        {
            alg=Moves.GenerateMoves();
        }
        else
        {
            system("CLS");
            Moves.LoadAlgorithm();
            cout<<"Algoritmi disponibili: \n";
            for(i=0;i<Moves.getnrAlg();i++)
            {
                cout<<i+1<<") "<<Moves.getAlgorithm(i).Name<<" : "<<Moves.getAlgorithm(i).Algorithm<<'\n';
            }
            cout<<"\nRecomandarile mele: \n";
            for(int x : Moves.getRecomandari())
            {
                cout<<x<<" ";
            }
            cout<<"\nAlegerea dumneavoastra:\n";
            cin>>choose;
            alg=Moves.getAlgorithm(choose-1).Algorithm;
        }
    }
    system("CLS");
    alg=Moves.repairString(alg);
    cout<<"Algoritm ales: \n"<<alg<<"\n";
    return alg;
}
int MainMenu::pascupas()
{
    int optiune;
    cout<<"Doriti sa afisati cubul: \n(1)pas cu pas;\n(2)algoritm cu algoritm;\n(3)algoritm aplicat de n ori;\n";
    cin>>optiune;
    return optiune;
}
