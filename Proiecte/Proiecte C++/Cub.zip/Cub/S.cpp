#include "S.h"
using namespace std;
string S::print()
{
    return "S";
}
string s::print()
{
    return "S\'";
}
string S::ReversePrint()
{
    return "S\'";
}
string s::ReversePrint()
{
    return "S";
}
void S::Execute(cube &cub)
{
    vector<int> aux,aux2;
    aux=cub.getRow(UP,2);
    aux2=cub.getColumn(RIGHT,2);
    cub.setColumn(RIGHT,2,aux);
    aux=aux2;
    aux2=cub.getRow(DOWN,2);
    reverse(aux.begin(),aux.end());
    cub.setRow(DOWN,2,aux);
    aux=aux2;
    aux2=cub.getColumn(LEFT,2);
    cub.setColumn(LEFT,2,aux);
    reverse(aux2.begin(),aux2.end());
    cub.setRow(UP,2,aux2);
}
void s::Execute(cube &cub)
{
    vector<int> aux,aux2;
    aux=cub.getRow(UP,2);
    aux2=cub.getColumn(LEFT,2);
    reverse(aux.begin(),aux.end());
    cub.setColumn(LEFT,2,aux);
    aux=aux2;
    aux2=cub.getRow(DOWN,2);
    cub.setRow(DOWN,2,aux);
    aux=aux2;
    reverse(aux.begin(),aux.end());
    aux2=cub.getColumn(RIGHT,2);
    cub.setColumn(RIGHT,2,aux);
    cub.setRow(UP,2,aux2);
}
