#pragma once
#define UP 1
#define DOWN 2
#define LEFT 3
#define FRONT 4
#define RIGHT 5
#define BACK 6
struct color
{
    int r,g,b;
}colors[10];
void colorInitialize()
{
    ///WHITE
    colors[UP].r=255;
    colors[UP].g=255;
    colors[UP].b=255;
    ///YELLOW
    colors[DOWN].r=255;
    colors[DOWN].g=255;
    colors[DOWN].b=0;
    ///BLUE
    colors[LEFT].r=0;
    colors[LEFT].g=128;
    colors[LEFT].b=255;
    ///ORANGE
    colors[FRONT].r=255;
    colors[FRONT].g=128;
    colors[FRONT].b=0;
    ///GREEN
    colors[RIGHT].r=0;
    colors[RIGHT].g=255;
    colors[RIGHT].b=0;
    ///RED
    colors[BACK].r=255;
    colors[BACK].g=0;
    colors[BACK].b=0;
}
