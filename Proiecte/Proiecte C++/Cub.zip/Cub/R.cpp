#include "R.h"
using namespace std;
string R::print()
{
    return "R";
}
string r::print()
{
    return "R\'";
}
string R::ReversePrint()
{
    return "R\'";
}
string r::ReversePrint()
{
    return "R";
}
void R::Execute(cube &x)
{
    vector<int> aux,aux2,aux3;
    aux = x.getColumn(FRONT,3);
    aux2= x.getColumn(UP,3);
    x.setColumn(UP,3,aux);
    aux=aux2;
    reverse(aux.begin(),aux.end());
    aux2= x.getColumn(BACK,1);
    x.setColumn(BACK,1,aux);
    aux=aux2;
    reverse(aux.begin(),aux.end());
    aux2= x.getColumn(DOWN,3);
    x.setColumn(DOWN,3,aux);
    aux=aux2;
    x.setColumn(FRONT,3,aux);
    aux = x.getRow(RIGHT,1);
    aux2 = x.getRow(RIGHT,2);
    aux3 = x.getRow(RIGHT,3);
    x.setColumn(RIGHT,3,aux);
    x.setColumn(RIGHT,2,aux2);
    x.setColumn(RIGHT,1,aux3);
}

void r::Execute(cube &x)
{
    vector<int> aux,aux2,aux3;
    aux = x.getColumn(FRONT,3);
    aux2= x.getColumn(DOWN,3);
    x.setColumn(DOWN,3,aux);
    aux=aux2;
    reverse(aux.begin(),aux.end());
    aux2= x.getColumn(BACK,1);
    x.setColumn(BACK,1,aux);
    aux=aux2;
    reverse(aux.begin(),aux.end());
    aux2= x.getColumn(UP,3);
    x.setColumn(UP,3,aux);
    aux=aux2;
    x.setColumn(FRONT,3,aux);
    aux = x.getColumn(RIGHT,1);
    aux2 = x.getColumn(RIGHT,2);
    aux3 = x.getColumn(RIGHT,3);
    x.setRow(RIGHT,3,aux);
    x.setRow(RIGHT,2,aux2);
    x.setRow(RIGHT,1,aux3);
}
