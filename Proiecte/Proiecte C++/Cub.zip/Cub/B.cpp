#include "B.h"
using namespace std;
string B::print()
{
    return "B";
}
string b::print()
{
    return "B\'";
}
string B::ReversePrint()
{
    return "B\'";
}
string b::ReversePrint()
{
    return "B";
}
void B::Execute(cube &x)
{
    vector<int> aux,aux2,aux3;
    aux = x.getRow(UP,1);
    aux2= x.getColumn(LEFT,1);
    reverse(aux.begin(),aux.end());
    x.setColumn(LEFT,1,aux);
    aux=aux2;
    aux2= x.getRow(DOWN,3);
    x.setRow(DOWN,3,aux);
    aux=aux2;
    aux2= x.getColumn(RIGHT,3);
    reverse(aux.begin(),aux.end());
    x.setColumn(RIGHT,3,aux);
    aux=aux2;
    x.setRow(UP,1,aux);
    aux = x.getRow(BACK,1);
    aux2 = x.getRow(BACK,2);
    aux3 = x.getRow(BACK,3);
    x.setColumn(BACK,3,aux);
    x.setColumn(BACK,2,aux2);
    x.setColumn(BACK,1,aux3);
}

void b::Execute(cube &x)
{
    vector<int> aux,aux2,aux3;
    aux = x.getRow(UP,1);
    aux2= x.getColumn(RIGHT,3);
    x.setColumn(RIGHT,3,aux);
    aux=aux2;
    aux2= x.getRow(DOWN,3);
    reverse(aux.begin(),aux.end());
    x.setRow(DOWN,3,aux);
    aux=aux2;
    aux2= x.getColumn(LEFT,1);
    x.setColumn(LEFT,1,aux);
    aux=aux2;
    reverse(aux.begin(),aux.end());
    x.setRow(UP,1,aux);
    aux = x.getColumn(BACK,1);
    aux2 = x.getColumn(BACK,2);
    aux3 = x.getColumn(BACK,3);
    x.setRow(BACK,3,aux);
    x.setRow(BACK,2,aux2);
    x.setRow(BACK,1,aux3);
}
