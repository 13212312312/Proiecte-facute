#pragma once
#include "mutare.h"
using namespace std;
class Z : public mutare
{
public:
    string print();
    void Execute(cube &cub);
    string ReversePrint();
};
class z : public mutare
{
public:
    string print();
    void Execute(cube &cub);
    string ReversePrint();
};
