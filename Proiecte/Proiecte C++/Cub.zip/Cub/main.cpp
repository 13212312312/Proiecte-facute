#include "meniu.h"
#include "cube.h"
#include <bits/stdc++.h>
#include "ListaMutari.h"
#include "thread"
using namespace std;
int main()
{
    MainMenu Meniu;
    Meniu.meniuPrincipal();
    return 0;
}
