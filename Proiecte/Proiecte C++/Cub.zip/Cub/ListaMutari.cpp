#include "ListaMutari.h"
#include <fstream>
ListaMutari::ListaMutari()
{
    this->NoRotation=27;
    this->nrAlg=0;
}
int ListaMutari::numberOfCharacters(string v)
{
    int i,nr;
    nr=0;
    for(i=0;i<=v.length();i++)
    {
        if(v[i]>='A'&&v[i]<='Z')
        {
            nr++;
        }
        if(v[i]=='\'')
        {
            nr++;
        }
    }
    return nr;
}
int ListaMutari::numberOfLetters(string v)
{
    int i,nr;
    nr=0;
    for(i=0;i<=v.length();i++)
    {
        if(v[i]>='A'&&v[i]<='Z')
        {
            nr++;
        }
    }
    return nr;
}
vector<int> ListaMutari::getRecomandari()
{
    return this->Recomandari;
}
int ListaMutari::getnrAlg()
{
    return this->nrAlg;
}
int ListaMutari::getNoRotation()
{
    return this->NoRotation;
}
string ListaMutari::getString(int poz)
{
    return this->str[poz];
}
algm ListaMutari::getAlgorithm(int poz)
{
    return this->AlgorithmList[poz];
}
string ListaMutari::repositionString(string v)
{
    string aux,newstring;
    int i;
    for(i=0;i<v.length();i++)
    {
        if(v[i]!=' ')
            aux+=v[i];
    }
    v=aux;
    aux=newstring;
    for(i=0;i<v.length();i++)
    {
        aux+=v[i];
        if((v[i+1]>='A' && v[i+1]<='Z') || (v[i+1]>='a' && v[i+1]<='z') )
            aux+=' ';
    }
    return aux;
}
string ListaMutari::repairString(string v)
{
    string aux;
    aux=this->fixString(v);
    while(aux!=v)
    {
        v=aux;
        aux=this->fixString(v);
    }
    return v;
}
string ListaMutari::fixString(string v)
{
    int nr=1,i;
    string aux[1001],rez;
    for(i=0;i<v.length();i++)
    {
        if(v[i]==' ')
        {
            nr++;
        }
        else
        {
            aux[nr]+=v[i];
        }
    }
    for(i=1;i<=nr;i++)
    {
        if(aux[i]+'\''==aux[i+1]||aux[i+1]+'\''==aux[i])
        {
            i++;
        }
        else
        if(aux[i]==aux[i+1]&&aux[i+1]==aux[i+2]&&aux[i+2]==aux[i+3])
        {
            i=i+3;
        }
        else
        if(aux[i]==aux[i+1]&&aux[i+1]==aux[i+2])
        {
            if(aux[i][1]=='\'')
                rez=rez+aux[i][0];
            else
                rez=rez+aux[i]+'\'';
            i=i+2;
        }
        else
            rez+=aux[i];
    }
    rez=repositionString(rez);
    return rez;
}
void ListaMutari::mutari()
{
    str[0]="L",str[1]="L2",str[2]="L'";
    str[3]="R",str[4]="R2",str[5]="R'";
    str[6]="U",str[7]="U2",str[8]="U'";
    str[9]="D",str[10]="D2",str[11]="D'";
    str[12]="F",str[13]="F2",str[14]="F'";
    str[15]="B",str[16]="B2",str[17]="B'";
    str[18]="M",str[19]="M2",str[20]="M'";
    str[21]="S",str[22]="S2",str[23]="S'";
    str[24]="E",str[25]="E2",str[26]="E'";
    str[27]="X",str[28]="X2",str[29]="X'";
    str[30]="Y",str[31]="Y2",str[32]="Y'";
    str[33]="Z",str[34]="Z2",str[35]="Z'";
}
void ListaMutari::LoadAlgorithm()
{
    ifstream f("Algorithms.txt");
    nrAlg=0;
    char s[101];
    string finish;
    do
    {
        f.getline(s,101);
        finish=s;
        this->AlgorithmList[this->nrAlg].Name=s;
        f.getline(s,101);
        this->AlgorithmList[this->nrAlg].Algorithm=s;
        this->AlgorithmList[this->nrAlg].Algorithm+=" Z'";
        this->AlgorithmList[this->nrAlg].Algorithm=this->repairString(this->AlgorithmList[this->nrAlg].Algorithm);
        this->nrAlg++;
    }while(finish!="END");
    nrAlg--;
    f.close();
}
string ListaMutari::GenerateMoves()
{
    mutari();
    int nr,x,aux,poz;
    nr=rand()%14+1;
    aux=rand()%2;
    if(aux==0) aux=19;
    else
        aux=22;
    string rez;
    while(nr)
    {
        nr--;
        x=rand()%aux+1;
        poz = (x-1) /2 * 3;
        poz = poz + (1-x%2)*2;
        rez+=str[poz];
    }
    rez=this->repairString(rez);
    return rez;
}
void ListaMutari::afisareMutari()
{
    mutari();
    int i;
    cout<<"Lista mutari valabile: \n";
    for(i=0;i<36;i++)
    {
        cout<<str[i]<<" ";
    }
    cout<<'\n';
}
