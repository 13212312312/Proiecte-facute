#pragma once
using namespace std;
class face
{
    int name;
    int value[4][4];
public:
    face(){};
    void setValue(int x);
    void setName(int x);
    int getValue(int i,int j);
    void setValue(int i,int j,int val);
    void rotation(int nr = 1);
    bool operator==(face b);
    void operator=(face b);
    void Print();
};
