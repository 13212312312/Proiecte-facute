#include "L.h"
using namespace std;
string L::print()
{
    return "L";
}
string l::print()
{
    return "L\'";
}
string L::ReversePrint()
{
    return "L\'";
}
string l::ReversePrint()
{
    return "L";
}
void L::Execute(cube &x)
{
    vector<int> aux,aux2,aux3;
    aux = x.getColumn(FRONT,1);
    aux2= x.getColumn(DOWN,1);
    x.setColumn(DOWN,1,aux);
    aux=aux2;
    aux2= x.getColumn(BACK,3);
    reverse(aux.begin(),aux.end());
    x.setColumn(BACK,3,aux);
    aux=aux2;
    reverse(aux.begin(),aux.end());
    aux2= x.getColumn(UP,1);
    x.setColumn(UP,1,aux);
    aux=aux2;
    x.setColumn(FRONT,1,aux);
    aux = x.getRow(LEFT,1);
    aux2 = x.getRow(LEFT,2);
    aux3 = x.getRow(LEFT,3);
    x.setColumn(LEFT,3,aux);
    x.setColumn(LEFT,2,aux2);
    x.setColumn(LEFT,1,aux3);
}
void l::Execute(cube &x)
{
    vector<int> aux,aux2,aux3;
    aux = x.getColumn(FRONT,1);
    aux2= x.getColumn(UP,1);
    x.setColumn(UP,1,aux);
    aux=aux2;
    reverse(aux.begin(),aux.end());
    aux2= x.getColumn(BACK,3);
    x.setColumn(BACK,3,aux);
    aux=aux2;
    reverse(aux.begin(),aux.end());
    aux2= x.getColumn(DOWN,1);
    x.setColumn(DOWN,1,aux);
    aux=aux2;
    x.setColumn(FRONT,1,aux);
    aux = x.getColumn(LEFT,1);
    aux2 = x.getColumn(LEFT,2);
    aux3 = x.getColumn(LEFT,3);
    x.setRow(LEFT,3,aux);
    x.setRow(LEFT,2,aux2);
    x.setRow(LEFT,1,aux3);
}
