#include "U.h"
using namespace std;
string U::print()
{
    return "U";
}
string u::print()
{
    return "U\'";
}
string U::ReversePrint()
{
    return "U\'";
}
string u::ReversePrint()
{
    return "U";
}
void U::Execute(cube &x)
{
    vector<int> aux,aux2,aux3;
    aux = x.getRow(LEFT,1);
    aux2= x.getRow(BACK,1);
    x.setRow(BACK,1,aux);
    aux=aux2;
    aux2= x.getRow(RIGHT,1);
    x.setRow(RIGHT,1,aux);
    aux=aux2;
    aux2= x.getRow(FRONT,1);
    x.setRow(FRONT,1,aux);
    aux=aux2;
    x.setRow(LEFT,1,aux);
    aux = x.getRow(UP,1);
    aux2 = x.getRow(UP,2);
    aux3 = x.getRow(UP,3);
    x.setColumn(UP,3,aux);
    x.setColumn(UP,2,aux2);
    x.setColumn(UP,1,aux3);
}

void u::Execute(cube &x)
{
    vector<int> aux,aux2,aux3;
    aux = x.getRow(LEFT,1);
    aux2= x.getRow(FRONT,1);
    x.setRow(FRONT,1,aux);
    aux=aux2;
    aux2= x.getRow(RIGHT,1);
    x.setRow(RIGHT,1,aux);
    aux=aux2;
    aux2= x.getRow(BACK,1);
    x.setRow(BACK,1,aux);
    aux=aux2;
    x.setRow(LEFT,1,aux);
    aux = x.getColumn(UP,1);
    aux2 = x.getColumn(UP,2);
    aux3 = x.getColumn(UP,3);
    x.setRow(UP,3,aux);
    x.setRow(UP,2,aux2);
    x.setRow(UP,1,aux3);
}
