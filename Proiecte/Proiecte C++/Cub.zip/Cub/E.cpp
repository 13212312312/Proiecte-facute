#include "E.h"
using namespace std;
string E::print()
{
    return "E";
}
string e::print()
{
    return "E\'";
}
string E::ReversePrint()
{
    return "E\'";
}
string e::ReversePrint()
{
    return "E";
}
void E::Execute(cube &cub)
{
    vector<int> aux,aux2;
    aux=cub.getRow(FRONT,2);
    aux2=cub.getRow(RIGHT,2);
    cub.setRow(RIGHT,2,aux);
    aux=aux2;
    aux2=cub.getRow(BACK,2);
    cub.setRow(BACK,2,aux);
    aux=aux2;
    aux2=cub.getRow(LEFT,2);
    cub.setRow(LEFT,2,aux);
    cub.setRow(FRONT,2,aux2);
}
void e::Execute(cube &cub)
{
    vector<int> aux,aux2;
    aux=cub.getRow(FRONT,2);
    aux2=cub.getRow(LEFT,2);
    cub.setRow(LEFT,2,aux);
    aux=aux2;
    aux2=cub.getRow(BACK,2);
    cub.setRow(BACK,2,aux);
    aux=aux2;
    aux2=cub.getRow(RIGHT,2);
    cub.setRow(RIGHT,2,aux);
    cub.setRow(FRONT,2,aux2);
}
