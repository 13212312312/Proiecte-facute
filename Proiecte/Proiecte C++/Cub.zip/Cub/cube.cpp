#include "cube.h"
#include "ListaMutari.h"
#include "L.h"
#include "R.h"
#include "B.h"
#include "F.h"
#include "D.h"
#include "U.h"
#include "X.h"
#include "Y.h"
#include "Z.h"
#include "M.h"
#include "S.h"
#include "E.h"
#include "RGB.h"
#define KEY_UP 72
#define KEY_DOWN 80
#define KEY_RIGHT 77
#define KEY_LEFT 75
std::thread thread1;
int page=1;
int page2=1;
int stopthread = 0;
ListaMutari MoveList;
void Square(int x1,int y1,int x2,int y2)
{
    line(x1,y1,x1,y2);
    line(x1,y2,x2,y2);
    line(x2,y2,x2,y1);
    line(x2,y1,x1,y1);
}
cube::cube()
{
    int i;
    int maxim=100001;
    finished=0;
    ListOfMoves=(string*) malloc(maxim * sizeof(string));
    cnt=0;
    solved=0;
    curent=1;
    NumberOfMoves=0;
    for(i=1;i<=6;i++)
    {
        fete[i].setValue(i);
        fete[i].setName(i);
    }
    nraplicari=0;
}
void cube::setSolvedState(int state)
{
    this->solved=state;
}
int cube::getSolvedState()
{
    return this->solved;
}
void cube::executeMove(string x)
{
    this->setMoves(x);
    this->Execute();
}
string cube::getSolution()
{
    if(this->getSolvedState()==1)
    {
        this->finalSolution=MoveList.repairString(this->finalSolution);
    }
    else
        this->Solve2();
    return this->finalSolution;
}
void cube::printSolveData(ostream& out)
{
    out<<"Rezolvat cu metoda: "<<this->getOption()<<'\n';
    out<<"Pentru a rezolva cubul trebuie aplicat: \n"<<this->getSolution()<<'\n';
    this->setMoves(this->getSolution());
}
string cube::Solve(int state,ostream& out)
{
    if (state==1)
    {
        thread1 = this->Solve1();
        return "Starting thread";
    }
    else
    {
        stopthread=1;
        thread1.join();
        if(!(this->getSolvedState()))
        {
            this->Solve2();
        }
        system("CLS");
        printSolveData(out);
        this->DrawOption(4);
    }
}
void cube::SolveAndDraw(int option)
{
    cube y;
    y=*this;
    y.Execute();
    y.Solve();
    this->DrawOption(option);
    y.Solve(2);
}
void cube::Solve2()
{
    string aux;
    int i;
    for(i=this->NumberOfMoves;i>0;i--)
    {
        aux=aux+this->ListOfMoves[i];
    }
    aux = MoveList.repairString(aux);
    this->option=2;
    this->setSolvedState(1);
    this->finalSolution=aux;
}
std::thread cube::Solve1()
{
    MoveList.mutari();
    cout<<"It may take a while \nsolving...\n";
    return std::thread( [this] { this->backtracking(); } );
}
void cube::backtracking()
{
    struct lst
    {
        string alg;
        int nr;
        int index;
        int cnt;
    };
    lst *myList;
    int maxim=1000001;
    int poz;
    myList=(lst*) malloc(maxim * sizeof(lst));
    lst curent;
    cube newcube,aux;
    int last=22,i;
    for(i=1;i<=22;i++)
    {
        poz = (i-1) /2 * 3;
        poz = poz + (1-i%2)*2;
        myList[i].alg=MoveList.getString(poz);
        myList[i].nr=1;
    }
    while(last&&(!this->getSolvedState()) && last < maxim && stopthread==0)
    {
        curent=myList[1];
        aux=*this;
        aux.executeMove(curent.alg);
        if(aux==newcube)
        {
            this->option=1;
            this->setSolvedState(1);
            this->finalSolution=curent.alg;
        }
        if(curent.nr<20)
        {
            for(i=1;i<=22;i++)
            {
                poz = (i-1) /2 * 3;
                poz = poz + (1-i%2)*2;
                if((!(poz==curent.index-2||poz==curent.index+2)) && (poz!=curent.index || curent.index!=2))
                {
                    last++;
                    myList[last].alg=curent.alg+MoveList.getString(poz);
                    myList[last].nr=curent.nr+1;
                    myList[last].index=i;
                    if(i==curent.index)
                    {
                        myList[last].cnt=curent.cnt+1;
                    }
                    else
                        myList[last].cnt=1;
                }
            }
        }
        for(i=1;i<last;i++)
        {
            myList[i]=myList[i+1];
        }
        last--;
    }
    if (last >= maxim)
        finalSolution = "Not found";
}
void cube::printAlgoritm(ostream& out,int index,int z,int t)
{
    int i,j,nr=0,rev=0;
    out<<"Numar mutari:  "<<this->cnt<<'\n';
    out<<"Algoritm aplicat: \n";
    string x,x2,aux,x3;
    x2+="^  ";
    nr=0;
    for(i=1;i<=cnt;i++)
    {
        aux=mutari[i]->print();
        x=x+aux;
        for(j=0;j<=aux.length()&&i>=index;j++)
        {
            if(aux[j]=='\''||aux[j]=='M')
                nr++;
            if(i==index)
            {
                if(aux[j]=='\'')
                    rev=1;
            }
        }
        if(i>index)
        {
            x3+=aux;
            x3+=" ";
        }
        x+=" ";
    }
    for(i=index+1;i<=cnt;i++)
    {
        x2+="    ";
    }
    for(i=1;i<nr;i++)
    {
        x2+=" ";
    }
    x3+="  ";
    x+="  ";
    if(index<=cnt)
    {
        x2+="  ";
    }
    for(i=1;i<=(cnt-index)/7;i++)
    {
        x2+=" ";
    }
    if(z!=1&&t!=-1)
    {
        out<<x;
        outstreamxy(z,t);
        if(index!=-1)
        {
            int n;
            n=x3.length();
            char spacing[n+1];
            strcpy(spacing,x3.c_str());\
            out<<"^ ";
            if(rev==1)
            {
                out<<" ";
            }
            outstreamxy(z-textwidth(spacing),t+textheight("A")*4);
        }
    }
    else
    {
        out<<x<<"\n";
        if(index!=-1) out<<x2<<"\n";
    }
}
int cube::getValue(int face,int x,int y)
{
    return this->fete[face].getValue(x,y);
}
void cube::transfer(cube a)
{
    int i;
    for(i=1;i<=6;i++)
    {
        this->setFace(a.getFace(i),i);
    }
}
int cube::verif()
{
    int i;
    for(i=1;i<=6;i++)
    {
        if(this->getValue(i,2,2)!=7&&this->getValue(i,2,2)!=i)
            return 0;
    }
    return 1;
}
cube cube::rotateCube()
{
    cube aux;
    aux=*this;
    int x,y,z;
    for(x=1;x<=4;x++)
    {
        for(y=1;y<=4;y++)
        {
            for(z=1;z<=4;z++)
            {
                aux.executeMove("Z");
                if(aux.verif())
                    return aux;
            }
            aux.executeMove("Y");
            if(aux.verif())
                return aux;
        }
        aux.executeMove("X");
        if(aux.verif())
            return aux;
    }
}
void cube::Print()
{
    cout<<"CUBUL NOSTRU: \n";
    int i;
    for(i=1;i<=6;i++)
    {
        switch(i){
            case 1:
                cout<<"UP:\n";
                break;
            case 2:
                cout<<"DOWN:\n";
                break;
            case 3:
                cout<<"LEFT:\n";
                break;
            case 4:
                cout<<"FRONT:\n";
                break;
            case 5:
                cout<<"RIGHT:\n";
                break;
            case 6:
                cout<<"BACK:\n";
                break;
            default:
                cout<<"EROARE:\n";
        };
        fete[i].Print();
    }
    this->printAlgoritm();
}
void cube::setMoves(string v)
{
    long long unsigned int i;
    this->alg=v;
    cnt=0;
    for (i=0;i<v.length();i++)
    {
            while(v[i]==' '&&i<v.length()) i++;
            if(i<v.length())
            {
                if ((v[i]=='M'&&v[i+1]=='\'')||(v[i]=='m'&&v[i+1]=='\''))
                    mutari[++cnt]=new m(),i++;
                if ((v[i]=='M')||(v[i]=='m'))
                    mutari[++cnt]=new M();
                if ((v[i]=='M'&&v[i+1]=='2')||(v[i]=='m'&&v[i+1]=='2'))
                    mutari[++cnt]=new M(),i++;

                if ((v[i]=='S'&&v[i+1]=='\'')||(v[i]=='s'&&v[i+1]=='\''))
                    mutari[++cnt]=new s(),i++;
                if ((v[i]=='S')||(v[i]=='s'))
                    mutari[++cnt]=new S();
                if ((v[i]=='S'&&v[i+1]=='2')||(v[i]=='s'&&v[i+1]=='2'))
                    mutari[++cnt]=new S(),i++;

                if ((v[i]=='E'&&v[i+1]=='\'')||(v[i]=='e'&&v[i+1]=='\''))
                    mutari[++cnt]=new e(),i++;
                if ((v[i]=='E')||(v[i]=='e'))
                    mutari[++cnt]=new E();
                if ((v[i]=='E'&&v[i+1]=='2')||(v[i]=='e'&&v[i+1]=='2'))
                    mutari[++cnt]=new E(),i++;

                if ((v[i]=='X'&&v[i+1]=='\'')||(v[i]=='x'&&v[i+1]=='\''))
                    mutari[++cnt]=new x(),i++;
                if ((v[i]=='X')||(v[i]=='x'))
                    mutari[++cnt]=new X();
                if ((v[i]=='X'&&v[i+1]=='2')||(v[i]=='x'&&v[i+1]=='2'))
                    mutari[++cnt]=new X(),i++;

                if ((v[i]=='Y'&&v[i+1]=='\'')||(v[i]=='y'&&v[i+1]=='\''))
                    mutari[++cnt]=new y(),i++;
                if ((v[i]=='Y')||(v[i]=='y'))
                    mutari[++cnt]=new Y();
                if ((v[i]=='Y'&&v[i+1]=='2')||(v[i]=='y'&&v[i+1]=='2'))
                    mutari[++cnt]=new Y(),i++;

                if ((v[i]=='Z'&&v[i+1]=='\'')||(v[i]=='z'&&v[i+1]=='\''))
                    mutari[++cnt]=new z(),i++;
                if ((v[i]=='Z')||(v[i]=='z'))
                    mutari[++cnt]=new Z();
                if ((v[i]=='Z'&&v[i+1]=='2')||(v[i]=='z'&&v[i+1]=='2'))
                    mutari[++cnt]=new Z(),i++;

                if ((v[i]=='L'&&v[i+1]=='\'')||(v[i]=='l'&&v[i+1]=='\''))
                    mutari[++cnt]=new l(),i++;
                if ((v[i]=='L')||(v[i]=='l'))
                    mutari[++cnt]=new L();
                if ((v[i]=='L'&&v[i+1]=='2')||(v[i]=='L'&&v[i+1]=='2'))
                    mutari[++cnt]=new L(),i++;

                if ((v[i]=='R'&&v[i+1]=='\'')||(v[i]=='r'&&v[i+1]=='\''))
                    mutari[++cnt]=new r(),i++;
                if ((v[i]=='R')||(v[i]=='r'))
                    mutari[++cnt]=new R();
                if ((v[i]=='R'&&v[i+1]=='2')||(v[i]=='r'&&v[i+1]=='2'))
                    mutari[++cnt]=new R(),i++;

                if ((v[i]=='B'&&v[i+1]=='\'')||(v[i]=='b'&&v[i+1]=='\''))
                    mutari[++cnt]=new b(),i++;
                if ((v[i]=='B')||(v[i]=='b'))
                    mutari[++cnt]=new B();
                if ((v[i]=='B'&&v[i+1]=='2')||(v[i]=='b'&&v[i+1]=='2'))
                    mutari[++cnt]=new B(),i++;

                if ((v[i]=='F'&&v[i+1]=='\'')||(v[i]=='f'&&v[i+1]=='\''))
                    mutari[++cnt]=new f(),i++;
                if ((v[i]=='F')||(v[i]=='f'))
                    mutari[++cnt]=new F();
                if ((v[i]=='F'&&v[i+1]=='2')||(v[i]=='f'&&v[i+1]=='2'))
                    mutari[++cnt]=new F(),i++;

                if ((v[i]=='U'&&v[i+1]=='\'')||(v[i]=='u'&&v[i+1]=='\''))
                    mutari[++cnt]=new u(),i++;
                if ((v[i]=='U')||(v[i]=='u'))
                    mutari[++cnt]=new U();
                if ((v[i]=='U'&&v[i+1]=='2')||(v[i]=='u'&&v[i+1]=='2'))
                    mutari[++cnt]=new U(),i++;

                if ((v[i]=='D'&&v[i+1]=='\'')||(v[i]=='d'&&v[i+1]=='\''))
                    mutari[++cnt]=new d(),i++;
                if ((v[i]=='D')||(v[i]=='d'))
                    mutari[++cnt]=new D();
                if ((v[i]=='D'&&v[i+1]=='2')||(v[i]=='d'&&v[i+1]=='2'))
                    mutari[++cnt]=new D(),i++;
            }
    }
}
vector<int> cube::getRow(int face,int row)
{
    vector<int> Row;
    int i,val;
    for(i=1;i<=3;i++)
    {
        val=fete[face].getValue(row,i);
        Row.push_back(val);
    }
    return Row;
}
vector<int> cube::getColumn(int face,int column)
{
    vector<int> Column;
    int i,val;
    for(i=1;i<=3;i++)
    {
        val=fete[face].getValue(i,column);
        Column.push_back(val);
    }
    return Column;
}
void cube::setColumn(int face,int column,vector<int> v)
{
    int i=0;
    for (auto x : v)
    {
        i++;
        fete[face].setValue(i,column,x);
    }
}
void cube::setRow(int face,int row,vector<int> v)
{
    int i=0;
    for (auto x : v)
    {
        i++;
        fete[face].setValue(row,i,x);
    }
}
void cube::DrawOption(int optiune)
{
    int n;
    switch(optiune)
    {
    case 1:
        this->Draw(this->howMany(),1);
        break;
    case 2:
        this->Draw(this->howMany());
        break;
    case 3:
        cout<<"n = ";
        cin>>n;
        this->Draw(n);
        break;
    default:
        this->Draw(1,1,1);
        break;
    }
}
/*void cube::Execute(int nr,int desen,int numar,int solving)
{
    int i,aux;
    if(desen==0)
    {
        this->nraplicari=nr;
    }
    while(nr>0)
    {
        nr--;
        for(i=1;i<=this->cnt;i++)
        {
            this->curent=i;
            mutari[i]->Execute(*this);
            this->NumberOfMoves++;
            this->ListOfMoves[this->NumberOfMoves]=mutari[i]->ReversePrint();
            if(desen==1)
            {
                this->DrawCube(numar,solving,this->curent);
            }
        }
    }
}*/
void cube::Execute(int nr,int desen,int numar,int solving)
{
    int i,aux;
    if(desen==0)
    {
        this->nraplicari=nr;
    }
    this->curent=1;
    while(nr>0)
    {
        mutari[this->curent]->Execute(*this);
        this->NumberOfMoves++;
        this->ListOfMoves[this->NumberOfMoves]=mutari[this->curent]->ReversePrint();
        if(desen==1)
        {
            this->DrawCube(numar,solving,this->curent);
        }
        this->curent++;
        if(this->curent>this->cnt)
        {
            this->curent=1;
            nr--;
        }
    }
}
face cube::getFace(int i)
{
    return this->fete[i];
}
void cube::setFace(face x,int i)
{
    this->fete[i]=x;
}
int cube::getCount()
{
    return this->cnt;
}
int cube::getOption()
{
    return this->option;
}
mutare* cube::getMutare(int i)
{
    return this->mutari[i];
}
bool cube::operator==(cube b)
{
    int nr=0,i,j;
    int verif[7];
    for(i=1;i<=6;i++)
    {
        verif[i]=0;
    }
    j=1;
    for(i=1;i<=6;i++)
    {
        for(j=1;j<=6;j++)
        if(this->fete[i]==b.getFace(j)&&verif[j]==0)
        {
            verif[j]=1;
            nr++;
        }
    }
    if (nr==6)
        return true;
    return false;
}
/**bool cube::operator==(cube b)
{
    cube a;
    face x,y;
    int i,j,k,ok;
    a=this->rotateCube();
    b=b.rotateCube();
    for(k=1;k<=6;k++)
    {
        ok=1;
        for(i=1;i<=3;i++)
        {
            for(j=1;j<=3;j++)
            {
                if(a.getValue(k,i,j)!=7&&b.getValue(k,i,j)!=7)
                {
                    if(a.getValue(k,i,j)!=b.getValue(k,i,j))
                        ok=0;
                }
            }
        }
        if(ok==0)
            return false;
    }
    return true;
}*/
int cube::getNumberOfMoves()
{
    return this->NumberOfMoves;
}
int cube::getFinishedState()
{
    return this->finished;
}
string cube::getFinalSolution()
{
    return this->finalSolution;
}
string cube::getListOfMoves(int i)
{
    return this->ListOfMoves[i];
}
int cube::getnraplicari()
{
    return this->nraplicari;
}
void cube::operator=(cube b)
{
    int i;
    for(i=1;i<=6;i++)
    {
        this->fete[i]=b.getFace(i);
    }
    this->cnt=b.getCount();
    for(i=1;i<=this->cnt;i++)
    {
        this->mutari[i]=b.getMutare(i);
    }
    this->solved=b.getSolvedState();
    this->option=b.getOption();
    this->NumberOfMoves=b.getNumberOfMoves();
    this->finished=b.getFinishedState();
    this->finalSolution=b.getFinalSolution();
    for(i=1;i<=this->NumberOfMoves;i++)
    {
        this->ListOfMoves[i]=b.getListOfMoves(i);
    }
}
void cube::Compare(cube y,ostream& out)
{
    if(*this==y)
        out<<"Cuburile sunt egale\n";
    else
        out<<"Cuburile nu sunt egale\n";
}
int cube::howMany(ostream& out,int index,int x,int y)
{
    cube aux=*this;
    cube complet=*this;
    int nr=0;
    do
    {
        nr++;
        aux.Execute();
    }while(!(aux==complet) && nr < 10000);
    if(nr==10000) nr=-1;
    if(nr==-1)
        out<<"Algoritmul nu a ajung la starea initiala(Probabil eroare din cod) \n";
    else
    {
        out<<"Numar total aplicari: "<<nr<<'\n';
        this->printAlgoritm(out,index,x,y);
    }
    return nr;
}
void cube::Draw(int nr,int pas,int solving)
{
    colorInitialize();
    int minim,aux;
    int page=1;
    DWORD rezolutiex=GetSystemMetrics(SM_CXSCREEN);
    DWORD rezolutiey=GetSystemMetrics(SM_CYSCREEN);
    minim=min(rezolutiex,rezolutiey);
    minim=2*minim/3;
    this->firstWindow=initwindow(2*minim,minim);
    this->DrawCube(nr,solving);
    aux=nr;
    while(nr)
    {
        nr--;
        this->Execute(1,pas,aux,solving);
        this->nraplicari=aux-nr;
        if(!pas)
            this->DrawCube(aux,solving);
    }
        this->nraplicari=aux-nr;
        this->DrawCube(aux,solving);
    closegraph();
}
void cube::drawChangeStringMeniu(int aux)
{
    int font,fontSize,direction,minim,boxLength,i,number,nrBoxes,j,nr,dimension;
    int x1,y1,x2,y2,poz;
    string CurentMove;
    DWORD rezolutiex=GetSystemMetrics(SM_CXSCREEN);
    DWORD rezolutiey=GetSystemMetrics(SM_CYSCREEN);
    minim=min(rezolutiex,rezolutiey);
    minim=2*minim/3;
    number=25;
    fontSize=4*minim/720;
    direction=1;
    font=3;
    nrBoxes=4;
    dimension=4;
    settextstyle(font,direction,fontSize);
    setactivepage(page2);
    setvisualpage(1-page2);
    readimagefile("bgr.jpg",0,0,3*minim/2,minim);
    this->howMany(bgiout,aux,3*minim/2,minim/10);
    bgiout<<"Work in progress!!";
    outstreamxy(3*minim/2,minim/10+textheight("A")*6);
    boxLength=minim/number;
    nr=0;
    for(i=1;i<=22;i++)
    {
        if(i%4==1)
        {
            for(j=1;j<=nrBoxes&&nr<24;j++)
            {
                nr++;
                x1=boxLength*((j-1)*dimension+1);
                y1=boxLength*i;
                x2=boxLength*((j-1)*dimension+dimension);
                y2=boxLength*(i+dimension-1);
                poz = (nr-1) /2 * 3;
                poz = poz + (1-nr%2)*2;
                CurentMove=MoveList.getString(poz);
                bgiout<<CurentMove;
                int n;
                n=CurentMove.length();
                char spacing[n+1];
                strcpy(spacing,CurentMove.c_str());
                outstreamxy((x1+x2)/2+textwidth(spacing)/2,(y1+y2)/2+textheight("A")/2);
                Square(x1,y1,x2,y2);
            }
        }
    }
    bgiout<<"Clear All";
    outstreamxy(3*minim/2-7*boxLength+textwidth("Clear All")/2,minim-5*boxLength/2+textheight("A")/2);
    bgiout<<"Delete";
    outstreamxy(3*minim/2-7*boxLength+textwidth("Delete")/2,minim-13*boxLength/2+textheight("A")/2);
    bgiout<<"Confirm";
    outstreamxy(3*minim/2-7*boxLength+textwidth("Confirm")/2,minim-21*boxLength/2+textheight("A")/2);
    Square(3*minim/2-13*boxLength,minim-4*boxLength,3*minim/2-boxLength,minim-boxLength);
    Square(3*minim/2-13*boxLength,minim-8*boxLength,3*minim/2-boxLength,minim-5*boxLength);
    Square(3*minim/2-13*boxLength,minim-12*boxLength,3*minim/2-boxLength,minim-9*boxLength);
    setvisualpage(page2);
    page2=1-page2;
}
int cube::ApplyOption(int option,int here,int poz)
{
    int nr=1,i,dif,pus=0;
    string aux[1001],rez;
    string v,fixed;
    v=this->alg;
    for(i=0;i<v.length();i++)
    {
        if(v[i]==' ')
        {
            nr++;
        }
        else
        {
            aux[nr]+=v[i];
        }
    }
    for(i=0;i<=nr;i++)
    {
        if(option==1)
        {
            rez+=aux[i];
            if(i==here)
            {
                rez+=MoveList.getString(poz);
                pus=1;
            }
        }
        if(option==2)
        {
            if(i!=here)
            {
                rez+=aux[i];
            }
        }
    }
    if(pus==0)
    {
        rez+=MoveList.getString(poz);
        pus=1;
    }
    fixed=MoveList.repairString(rez);
    this->alg=MoveList.repairString(rez);
    this->setMoves(alg);
    int LetterA,CharacterA,LetterB,CharacterB;
    CharacterA=MoveList.numberOfCharacters(fixed);
    CharacterB=MoveList.numberOfCharacters(rez);
    LetterA=MoveList.numberOfLetters(fixed);
    LetterB=MoveList.numberOfLetters(rez);
    here++;
    if(option==1)
    {
        if(CharacterA==CharacterB)
        {
            return max(0,here);
        }
        else
        {
            dif=abs(LetterA-LetterB);
            return max(0,here-dif);
        }
    }
    else
    {
        if(option==2)
        {
            return max(0,here-2);
        }
    }
}
int cube::checkMove(int x,int y,int where)
{
    int number,minim,boxLength,dimension,nrBoxes,maxRight;
    int i,j,nr,poz;
    dimension=4;
    nrBoxes=4;
    DWORD rezolutiex=GetSystemMetrics(SM_CXSCREEN);
    DWORD rezolutiey=GetSystemMetrics(SM_CYSCREEN);
    minim=min(rezolutiex,rezolutiey);
    minim=2*minim/3;
    number=25;
    boxLength=minim/number;
    maxRight=boxLength*((nrBoxes-1)*dimension+dimension);
    if(x<=maxRight)
    {
        i=y/boxLength;
        j=x/boxLength;
        if(i%dimension!=0&&j%dimension!=0)
        {
            i=i/dimension+1;
            j=j/dimension+1;
            nr=(i-1)*nrBoxes+j;
            poz = (nr-1) /2 * 3;
            poz = poz + (1-nr%2)*2;
            return this->ApplyOption(1,where,poz);
        }
        else return where;
    }
    else
    {
        if(x>=3*minim/2-13*boxLength && x<=3*minim/2-boxLength)
        {
            if(y>=minim-4*boxLength && y<=minim-boxLength)
            {
                this->cnt=0;
                this->setMoves("");
                return 0;
            }
            else
            {
                if(y>=minim-8*boxLength && y<=minim-5*boxLength)
                {
                    return this->ApplyOption(2,where);
                }
                else
                {
                    if(y>=minim-12*boxLength && y<=minim-9*boxLength)
                    {
                        return -10;
                    }
                    else
                    {
                        return where;
                    }
                }
            }
        }
        else
        {
            return where;
        }
    }
}
void cube::changeString(int index)
{
    int minim,inLoop=1,modified=1;
    int key;
    int aux,aux2;
    DWORD rezolutiex=GetSystemMetrics(SM_CXSCREEN);
    DWORD rezolutiey=GetSystemMetrics(SM_CYSCREEN);
    minim=min(rezolutiex,rezolutiey);
    minim=2*minim/3;
    this->secondWindow=initwindow(3*minim/2,minim);
    aux=this->curent;
    this->drawChangeStringMeniu(aux);
    while(inLoop)
    {
        if(ismouseclick(WM_LBUTTONDOWN))
        {
            aux=this->checkMove(mousex(),mousey(),aux);
            if(aux==-10)
            {
                inLoop=0;
            }
            else
            {
                if(aux<0)
                {
                    aux=0;
                }
                if(aux>this->cnt)
                {
                    aux=this->cnt;
                }
            }
            clearmouseclick(WM_LBUTTONDOWN);
            modified=1;
        }
        if(kbhit())
        {
            key=getch();
            if(key==KEY_RIGHT&&aux<this->cnt)
            {
                aux++;
                modified=1;
            }
            if(key==KEY_LEFT&&aux>0)
            {
                aux--;
                modified=1;
            }
        }
        if(aux!=-10)
        {
            aux2=aux;
        }
        if(modified==1)
        {
            modified=0;
            this->drawChangeStringMeniu(aux);
        }
    }
    while(kbhit())
    {
        getch();
    }
    if(aux2<=this->curent)
    {
        this->curent=aux2;
    }
    closegraph(this->secondWindow);
    setcurrentwindow(this->firstWindow);
}
void cube::DrawCube(int numar,int solving,int index)
{
    char key;
    setactivepage(page);
    setvisualpage(1-page);
    int cubeLength,i,x,j,y,minim,clr,aux,aux2,topx,topy,k,nr,fillnr;
    fillnr=0;
    char FILLSTYLE[6][8] = {
    {0x00, 0x41, 0x41, 0x49, 0x55, 0x63, 0x41, 0x00},  /// W
    {0x22, 0x22, 0x36, 0x1C, 0x08, 0x08, 0x08, 0x00},  /// Y
    {0x38, 0x24, 0x24, 0x38, 0x24, 0x24, 0x38, 0x00},  /// B
    {0x1C, 0x22, 0x22, 0x22, 0x22, 0x22, 0x1C, 0x00},  /// O
    {0x18, 0x24, 0x24, 0x20, 0x2C, 0x24, 0x18, 0x00},  /// G
    {0x38, 0x24, 0x24, 0x24, 0x38, 0x24, 0x24, 0x00}}; /// R
    int fontSize,font,direction;
    direction=1;
    font=3;
    face b;
    DWORD rezolutiex=GetSystemMetrics(SM_CXSCREEN);
    DWORD rezolutiey=GetSystemMetrics(SM_CYSCREEN);
    minim=min(rezolutiex,rezolutiey);
    cubeLength=minim/10;
    minim=2*minim/3;
    fontSize=4*minim/720;
    readimagefile("bgr.jpg",0,0,2*minim,minim);
    aux=2*cubeLength/3;
    settextstyle(font,direction,fontSize);
    this->howMany(bgiout,index,minim*2,minim/10);
    if(solving==1)
    {
        this->printSolveData(bgiout);
        bgiout<<"Cubul nostru:\n";
        outstreamxy(textwidth("Pentru a rezolva cubul trebuie aplicat:    "),minim/10);
    }
    else
    {
        bgiout<<"Numar aplicari: "<<this->nraplicari<<" / "<<numar<<"\n";
        bgiout<<"Cubul nostru:\n";
        outstreamxy(textwidth("Numar aplicari: 1111 / 1111"),minim/10);
    }
    for(k=0;k<=1;k++)
    {
        aux=2*cubeLength/3;
        for(i=minim/2;i<=minim/2+cubeLength*3;i=i+cubeLength)
        {
            line(minim/2+minim*k,i,minim/2+cubeLength*3+minim*k,i);
            line(minim/2-cubeLength*2+minim*k,i-cubeLength,minim/2+minim*k,i);
            line(i+minim*k,minim/2,i+minim*k,minim/2+cubeLength*3);
            line(i-cubeLength*2+minim*k,minim/2-cubeLength,i+minim*k,minim/2);
        }
        j=minim/2;
        for(i=minim/2-aux;i>=minim/2-3*aux;i=i-aux)
        {
            j=j-aux/2;
            line(i+minim*k,j,i+3*cubeLength+minim*k,j);
            line(i+minim*k,j,i+minim*k,j+3*cubeLength);
        }
        topy=minim/2-cubeLength;
        topx=minim/2-cubeLength*2+minim*k;
        aux=cubeLength;
        aux2=2*cubeLength/3;
        for(i=1;i<=3;i++)
            for(j=1;j<=3;j++)
            {
                x=(j-1)*cubeLength+minim/2+cubeLength/2;
                y=(i-1)*cubeLength+minim/2+cubeLength/2;
                if(k==0)
                    clr=this->getFace(FRONT).getValue(i,j);
                else
                    clr=this->getFace(RIGHT).getValue(4-i,4-j);
                setfillpattern(FILLSTYLE[clr-1],COLOR(colors[clr].r,colors[clr].g,colors[clr].b));
                floodfill(x+minim*k,y,WHITE);
            }
        for(i=1;i<=3;i++)
        {
            for(j=1;j<=3;j++)
            {
                x=topx+aux2*(i-1)+aux2/2;
                y=topy+aux*(j-1)+aux/2+i*aux/3;
                if(k==0)
                    clr=this->getFace(LEFT).getValue(j,i);
                else
                    clr=this->getFace(BACK).getValue(4-j,4-i);
                setfillpattern(FILLSTYLE[clr-1],COLOR(colors[clr].r,colors[clr].g,colors[clr].b));
                floodfill(x,y,WHITE);
            }
        }
        aux2=cubeLength/3;
        for(i=1;i<=3;i++)
        {
            for(j=1;j<=3;j++)
            {
                x=topx+aux*(i-1)+aux/2+j*(3*aux/6);
                y=topy+aux2*(j-1)+aux2/2;
                b=this->getFace(DOWN);
                b.rotation();
                if(k==0)
                    clr=this->getFace(UP).getValue(j,i);
                else
                    clr=b.getValue(4-j,4-i);
                setfillpattern(FILLSTYLE[clr-1],COLOR(colors[clr].r,colors[clr].g,colors[clr].b));
                floodfill(x,y,WHITE);
            }
        }
    }
    setvisualpage(page);
    page=1-page;
    key=getch();
    if(key=='x'&&solving==0)
    {
        this->changeString(index);
    }
}
