#include "mutare.h"
using namespace std;
class R : public mutare
{
public:
    string print();
    void Execute(cube &x);
    string ReversePrint();
};
class r : public mutare
{
public:
    string print();
    void Execute(cube &x);
    string ReversePrint();
};
