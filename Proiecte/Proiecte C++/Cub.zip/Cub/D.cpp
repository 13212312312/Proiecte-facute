#include "D.h"
using namespace std;
string D::print()
{
    return "D";
}
string d::print()
{
    return "D\'";
}
string D::ReversePrint()
{
    return "D\'";
}
string d::ReversePrint()
{
    return "D";
}
void D::Execute(cube &x)
{
    vector<int> aux,aux2,aux3;
    aux = x.getRow(LEFT,3);
    aux2= x.getRow(FRONT,3);
    x.setRow(FRONT,3,aux);
    aux=aux2;
    aux2= x.getRow(RIGHT,3);
    x.setRow(RIGHT,3,aux);
    aux=aux2;
    aux2= x.getRow(BACK,3);
    x.setRow(BACK,3,aux);
    aux=aux2;
    x.setRow(LEFT,3,aux);
    aux = x.getRow(DOWN,1);
    aux2 = x.getRow(DOWN,2);
    aux3 = x.getRow(DOWN,3);
    x.setColumn(DOWN,3,aux);
    x.setColumn(DOWN,2,aux2);
    x.setColumn(DOWN,1,aux3);
}

void d::Execute(cube &x)
{
    vector<int> aux,aux2,aux3;
    aux = x.getRow(LEFT,3);
    aux2= x.getRow(BACK,3);
    x.setRow(BACK,3,aux);
    aux=aux2;
    aux2= x.getRow(RIGHT,3);
    x.setRow(RIGHT,3,aux);
    aux=aux2;
    aux2= x.getRow(FRONT,3);
    x.setRow(FRONT,3,aux);
    aux=aux2;
    x.setRow(LEFT,3,aux);
    aux = x.getColumn(DOWN,1);
    aux2 = x.getColumn(DOWN,2);
    aux3 = x.getColumn(DOWN,3);
    x.setRow(DOWN,3,aux);
    x.setRow(DOWN,2,aux2);
    x.setRow(DOWN,1,aux3);
}
