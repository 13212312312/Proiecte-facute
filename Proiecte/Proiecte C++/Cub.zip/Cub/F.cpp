#include "F.h"
using namespace std;
string F::print()
{
    return "F";
}
string f::print()
{
    return "F\'";
}
string F::ReversePrint()
{
    return "F\'";
}
string f::ReversePrint()
{
    return "F";
}
void F::Execute(cube &x)
{
    vector<int> aux,aux2,aux3;
    aux = x.getRow(UP,3);
    aux2= x.getColumn(RIGHT,1);
    x.setColumn(RIGHT,1,aux);
    aux=aux2;
    aux2= x.getRow(DOWN,1);
    reverse(aux.begin(),aux.end());
    x.setRow(DOWN,1,aux);
    aux=aux2;
    aux2= x.getColumn(LEFT,3);
    x.setColumn(LEFT,3,aux);
    aux=aux2;
    reverse(aux.begin(),aux.end());
    x.setRow(UP,3,aux);
    aux = x.getRow(FRONT,1);
    aux2 = x.getRow(FRONT,2);
    aux3 = x.getRow(FRONT,3);
    x.setColumn(FRONT,3,aux);
    x.setColumn(FRONT,2,aux2);
    x.setColumn(FRONT,1,aux3);
}

void f::Execute(cube &x)
{
    vector<int> aux,aux2,aux3;
    aux = x.getRow(UP,3);
    aux2= x.getColumn(LEFT,3);
    reverse(aux.begin(),aux.end());
    x.setColumn(LEFT,3,aux);
    aux=aux2;
    aux2= x.getRow(DOWN,1);
    x.setRow(DOWN,1,aux);
    aux=aux2;
    reverse(aux.begin(),aux.end());
    aux2= x.getColumn(RIGHT,1);
    x.setColumn(RIGHT,1,aux);
    aux=aux2;
    x.setRow(UP,3,aux);
    aux = x.getColumn(FRONT,1);
    aux2 = x.getColumn(FRONT,2);
    aux3 = x.getColumn(FRONT,3);
    x.setRow(FRONT,3,aux);
    x.setRow(FRONT,2,aux2);
    x.setRow(FRONT,1,aux3);
}

