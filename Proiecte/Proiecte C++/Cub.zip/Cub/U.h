#include "mutare.h"
using namespace std;
class U : public mutare
{
public:
    string print();
    void Execute(cube &x);
    string ReversePrint();
};
class u : public mutare
{
public:
    string print();
    void Execute(cube &x);
    string ReversePrint();
};
