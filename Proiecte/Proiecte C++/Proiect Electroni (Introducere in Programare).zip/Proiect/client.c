#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <errno.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <netdb.h>
#include <dirent.h>
#include <string.h>
#include <arpa/inet.h>
#define clearScreen() system("@cls||clear")
extern int errno;
int port;
struct clas
{
	int poz;
	int id;
	int punctaj;
}clasament[100];
int nrparticipanti;
int adauga(char a[],int id)
{
	char aux[100];
	sprintf(aux,"%d",id);
	strcat(a,aux);
}
int esteNumar(char a[])
{
	int nr=0;
	int ok=1,i;
	for(i=0;i<strlen(a);i++)
	{
		if(!(a[i]>='0'&&a[i]<='9'))
		{
			ok=0;
		}
		nr=nr*10+a[i]-'0';
	}
	if(ok)
		return nr;
	return ok;
}
int main (int argc, char *argv[])
{
	int sd;
	struct sockaddr_in server;
	pid_t mypid;
	char msg[100];
	char aux[30000];
	char nume[100];
	int bytes;
	char citeste[1000];
	int ruleaza=1;
	int optiune;
	int nrparticipanti;
	FILE* cerinta;
	int id=-1;
	mypid=getpid();
	if (argc != 3)
	{
		printf ("[client] Sintaxa: %s <adresa_server> <port>\n", argv[0]);
		return -1;
	}
	port = atoi (argv[2]);
	if ((sd = socket (AF_INET, SOCK_STREAM, 0)) == -1)
	{
		perror ("[client] Eroare la socket().\n");
		return errno;
	}
	server.sin_family = AF_INET;
	server.sin_addr.s_addr = inet_addr(argv[1]);
	server.sin_port = htons (port);
	if (connect (sd, (struct sockaddr *) &server,sizeof (struct sockaddr)) == -1)
	{
		perror ("[client]Eroare la connect().\n");
		return errno;
	}
	if ((bytes = write (sd, &mypid, sizeof(pid_t))) <= 0)
	{
		perror ("[client]Eroare la write() spre server.\n");
		return errno;
	}
	while(ruleaza)
	{
		bzero (msg, 100);
		if(id==-1)
		{
			printf ("[client]Introduceti comanda \"Connect\" daca doriti sa incepeti sa rezolvati:\n ");
		}
		else
		{
			printf("ID-ul dumneavoastra este: %d\n",id);
		}
		
		read (0, msg, 100);
		if (write (sd, msg, 100) <= 0)
		{
			perror ("[client]Eroare la write() spre server.\n");
			return errno;
		}
		bzero(msg,100);
		if (read (sd, msg, 100) < 0)
		{
			perror ("[client]Eroare la read() de la server.\n");
			return errno;
		}
		msg[strlen(msg)]='\0';
		printf ("[client]Mesajul primit este: \n%s\n", msg);
		if(strcmp(msg,"Conectat cu success!")==0)
		{
			if (read (sd, msg, 100) < 0)
			{
				perror ("[client]Eroare la read() de la server.\n");
				return errno;
			}
			if(id==-1)
			{
				msg[strlen(msg)]='\0';
				id=esteNumar(msg);
			}
			if (read (sd, msg, 100) < 0)
			{
				perror ("[client]Eroare la read() de la server.\n");
				return errno;
			}
			int ok;
			strcpy(nume,"cerinta");
			adauga(nume,id);
			strcat(nume,".txt");
			cerinta=fopen(nume,"w");
			ok=1;
			bytes = 0;
			if((bytes = read(sd,aux,20000)) <= 0)
			{
				perror("[client] Eroare la read() de la server\n");
				return errno;
			}
			fprintf(cerinta,"%s\n",aux);
			fclose(cerinta);
			ruleaza=0;
		}
	}
	ruleaza=1;
	clearScreen();
	char temp[100];
	char fname[100];
	strcpy(fname,"rezolvare");
	adauga(fname,id);
	strcat(fname,".txt");
	if( access( fname, F_OK ) == 0 ) 
	{
		strcpy(temp,"rm ");
		strcat(temp,fname);
		system(temp);
	}
	int editat=0;
	while(ruleaza)
	{
		printf("ID-ul dumneavoastra este: %d\n",id);
		printf("Alegeti optiunea:\n1)Cititi cerinta\n2)Rezolvati cerinta\n3)Trimiteti Rezolvarea\n");
		scanf("%d",&optiune);
		switch(optiune)
		{
			case 1:
				cerinta=fopen(nume,"r");
				clearScreen();
				while (fgets(temp, 1000, cerinta))
				{
					printf("%s",temp);
			    }
			    fclose(cerinta);
				break;
			case 2:
				strcpy(temp,"mcedit ");
				strcat(temp,fname);
				system(temp);
				editat=1;
				clearScreen();
				break;
			case 3:
				if(editat==1) 
				{
					ruleaza=0;
				}
				else 
				{
					clearScreen(); 
					printf("Va rugam rezolvati problema intai!\n");
				}
				break;
			default:
				printf("Optiune invalida!\n");
		}
	}
	bzero(aux,30000);
	bzero(citeste,1000);
	cerinta=fopen(fname,"r");
	while (fgets(citeste, 1000, cerinta))
	{
		strcat(aux,citeste);
    }
    fclose(cerinta);
    if (write (sd, aux, 20000) < 0)
	{
		perror ("[client]Eroare la read() de la server.\n");
		return errno;
	}
	printf("Se asteapta scurgerea timpului!\n");
	if (read (sd, &nrparticipanti, sizeof(int)) < 0)
	{
		perror ("[client]Eroare la read() de la server.\n");
		return errno;
	}
	if (read (sd, &clasament, sizeof(clasament)) < 0)
	{
		perror ("[client]Eroare la read() de la server.\n");
		return errno;
	}
	for(int i=1;i<=nrparticipanti;i++)
	{
		printf("Locul: %d, Participantul cu numarul: %d, Numar total de puncte: %d\n", clasament[i].poz, clasament[i].id, clasament[i].punctaj);
	}
	close(sd);
}
