#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <netdb.h>
#include <string.h>
#include <time.h>
void move(char* oldpath,char* newpath)
{
	FILE* old;
	FILE* new;
	int size;
	old=fopen(oldpath,"r");
	new=fopen(newpath,"w");
	if (NULL != old) 
	{
		fseek (old, 0, SEEK_END);
		size = ftell(old);
		fclose(old);
		if (0 == size && strstr(oldpath,".out")) 
		{
		    fprintf(new,"CevaRandomCaSaDeaRaspunsGresitPentruCaAsaVreauEu>:(\n");
		}
		else
		{
			old=fopen(oldpath,"r");
			char c;
			c = fgetc(old);
			while(c != EOF) 
			{
				fprintf(new,"%c",c);
				c = fgetc(old);
			}
			fclose(old);
		}
	}
	fclose(new);
}
int verify(char* path)
{
    FILE *file;
    if ((file = fopen(path, "r")))
    {
        fclose(file);
        return 1;
    }
    return 0;
}
void createfake(char* fake)
{
    FILE *file;
    file = fopen(fake, "w");
	fprintf(file,"fakefile");
    fclose(file);
}
void removeAllFiles(char* file,char* who)
{
	int i;
	int exista;
	char comanda[100];
	char* oldpath;
	char* newpath;
	oldpath=(char*)malloc(100);
	newpath=(char*)malloc(100);
	for(i=1;i<=6;i++)
	{
		strcpy(oldpath,file);
		strcat(oldpath,who);
		strcpy(newpath,"Probleme/");
		strcat(newpath,file);
		strcat(newpath,"/");
		strcat(newpath,who);
		strcat(newpath,"/");
		if(i<=5)
		{
			strcat(newpath,file);
			strcat(newpath,who);
			switch (i)
			{
				case 1:
					strcat(oldpath,".err");
					strcat(newpath,".err");
					break;
				case 2:
					strcat(oldpath,".war");
					strcat(newpath,".war");
					break;
				case 3:
					strcat(oldpath,".info");
					strcat(newpath,".info");
					break;
				case 4:
					strcat(oldpath,".out");
					strcat(newpath,".out");
					break;
				case 5:
					strcat(oldpath,".in");
					strcat(newpath,".in");
					break;
				default:
					return;
			}
		}
		else
		{
			strcat(newpath,"detalii");
			strcat(newpath,who);
			strcat(newpath,".info");
			strcpy(oldpath,"detalii");
			strcat(oldpath,who);
			strcat(oldpath,".info");
		}
		strcat(oldpath,"\0");
		strcat(newpath,"\0");
		if(i!=5)
		{
			if(verify(oldpath))
			{
				move(oldpath,newpath);
			}
			else
			{
				createfake(oldpath);
			}
		}
		exista = verify(oldpath);
		strcpy(comanda,"rm ");
		strcat(comanda,oldpath);
		if(exista) system(comanda);
	}
	strcpy(newpath,file);
	strcat(newpath,who);
	exista = verify(newpath);
    strcpy(comanda,"rm ");
    strcat(comanda,file);
    strcat(comanda,who);
	if(exista) system(comanda);
}
int main(int argc,char* argv[])
{
	FILE* fp;
	FILE* detalii;
	FILE* detaliifinale;
	int eroare;
	char comanda[400],fisierdetalii[400];
	int size;
	int warning;
	
	strcpy(fisierdetalii,argv[1]);
	strcat(fisierdetalii,argv[2]);
	strcat(fisierdetalii,".info");
	
	detalii = fopen(fisierdetalii,"w");
	
	strcpy(fisierdetalii,"detalii");
	strcat(fisierdetalii,argv[2]);
	strcat(fisierdetalii,".info");
	detaliifinale = fopen(fisierdetalii,"w");
	
	strcpy(comanda,"gcc Probleme/");
	strcat(comanda,argv[1]);
	strcat(comanda,"/");
	strcat(comanda,argv[2]);
	strcat(comanda,"/");
	strcat(comanda,argv[1]);
	strcat(comanda,".c -o ");
	strcat(comanda,argv[1]);
	strcat(comanda,argv[2]);
	strcat(comanda," 2> ");
	strcat(comanda,argv[1]);
	strcat(comanda,argv[2]);
	strcat(comanda,".err");
	
	system(comanda);
	
	strcpy(comanda,"gcc Probleme/");
	strcat(comanda,argv[1]);
	strcat(comanda,"/");
	strcat(comanda,argv[2]);
	strcat(comanda,"/");
	strcat(comanda,argv[1]);
	strcat(comanda,".c -Wall -o ");
	strcat(comanda,argv[1]);
	strcat(comanda,argv[2]);
	strcat(comanda," 2> ");
	strcat(comanda,argv[1]);
	strcat(comanda,argv[2]);
	strcat(comanda,".war");
	
	system(comanda);
	
	strcpy(comanda,argv[1]);
	strcat(comanda,argv[2]);
	strcat(comanda,".err");
	
	fp = fopen(comanda,"r");
	if (NULL != fp) 
	{
		fseek (fp, 0, SEEK_END);
		size = ftell(fp);
		fclose(fp);
		if (0 == size) 
		{
			eroare=0;
		    fprintf(detalii,"Compilare cu success\n");
		    fprintf(detaliifinale,"Compilare cu success\n");
		}
		else
		{
			eroare=1;
			fprintf(detalii,"Eroare de compilare\n");
			fprintf(detaliifinale,"Eroare de compilare\n");
		}
	}
	
	strcpy(comanda,argv[1]);
	strcat(comanda,argv[2]);
	strcat(comanda,".war");
	fp = fopen(comanda,"r");
	
	if (NULL != fp) 
	{
		fseek (fp, 0, SEEK_END);
		size = ftell(fp);
		fclose(fp);
		if (0 == size) 
		{
			warning=0;
		    fprintf(detalii,"Fara warning-uri , felicitari!\n");
		    fprintf(detaliifinale,"Fara warning-uri , felicitari!\n");
		}
		else
		{
			warning=1;
			fprintf(detalii,"Exista warning-uri\n");
			fprintf(detaliifinale,"Exista warning-uri\n");
		}
	}
	
	struct timeval time1;
	if(gettimeofday( &time1, 0 )) return -1;
	long cur_time1 = 1000000 * time1.tv_sec + time1.tv_usec;
	
	if(eroare==0)
	{
		strcpy(comanda,"./");
		strcat(comanda,argv[1]);
		strcat(comanda,argv[2]);
		system(comanda);
	}
	
	struct timeval time2;
	if(gettimeofday( &time2, 0 )) return -1;
	long cur_time2 = 1000000 * time2.tv_sec + time2.tv_usec;
	double sec = (cur_time2 - cur_time1)/ 1000000.0;
	
	fprintf(detalii,"Timpul de executare:%lf\n",sec);
	fclose(detalii);
	fclose(detaliifinale);
	removeAllFiles(argv[1],argv[2]);
	strcpy(comanda,"rm ");
	strcat(comanda,argv[0]);
	system(comanda);
}
