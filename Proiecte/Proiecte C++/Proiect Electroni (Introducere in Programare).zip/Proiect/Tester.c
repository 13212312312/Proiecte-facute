#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <netdb.h>
#include <string.h>
#include <time.h>
int verify(char* path)
{
    FILE *file;
    if ((file = fopen(path, "r")))
    {
        fclose(file);
        return 1;
    }
    return 0;
}
int compareFile(char* file1, char* file2)
{
	FILE* fPtr1;
	FILE* fPtr2;
	fPtr1 = fopen(file1,"r");
	fPtr2 = fopen(file2,"r");
    char ch1, ch2;
	ch1 = fgetc(fPtr1);
	ch2 = fgetc(fPtr2);
    while(ch1 != EOF && ch2 != EOF) 
	{
		if(ch1 != ch2) return 0;
		ch1 = fgetc(fPtr1);
		ch2 = fgetc(fPtr2);
	}
    if (ch1 == EOF || ch2 == EOF)
        return 1;
    else
        return 0;
}
void move(char* oldpath,char* newpath)
{
	FILE* old;
	FILE* new;
	old=fopen(oldpath,"r");
	new=fopen(newpath,"w");
	char c = fgetc(old);
	while (c != EOF) 
	{
		fprintf(new,"%c",c);
		c = fgetc(old);
	}
	fclose(old);
	fclose(new);
}
int main(int argc,char* argv[])
{
	int numarTeste,i,nr,copieTest,j,pct,nrpuncte;
	char path[400],input[400],output[400],aux[400],nrteste[400],swapaux,comanda[400],timp[400],timp2[400];
	double timpexec;
	double timptotal=0.1;
	FILE* punctaj;
	FILE* in;
	FILE* out;
	FILE* detalii;
	FILE* time;
	strcpy(aux,"utilizator");
	strcat(aux,argv[2]);
	strcpy(argv[2],aux);
	
	strcpy(path,"Probleme/");
	strcat(path,argv[1]);
	
	
	strcpy(aux,path);
	strcat(aux,"/");
	strcat(aux,argv[2]);
	strcat(aux,"/");
	
	strcpy(timp2,path);
	strcat(timp2,"/timp.txt");
	time=fopen(timp2,"r");
	fscanf(time,"%lf",&timptotal);
	fclose(time);
	
	strcpy(timp,aux);
	strcat(timp,argv[1]);
	strcat(timp,argv[2]);
	strcat(timp,".info");
	
	
	strcat(path,"/teste/");
	
	strcpy(nrteste,path);
	strcat(nrteste,"nrteste.txt");
	
	punctaj=fopen(nrteste,"r");
	
	fscanf(punctaj,"%d",&numarTeste);
	
	strcat(aux,"detalii");
	strcat(aux,argv[2]);
	strcat(aux,".info");
	
	if(verify(aux)) detalii=fopen(aux,"a");
	pct=0;
	
	for(i=1;i<=numarTeste;i++)
	{
		strcpy(aux,"gcc Compilator.c -o compilator");
		strcat(aux,argv[2]);
		system(aux);
		nr=0;
		strcpy(aux,"");
		copieTest=i;
		while(copieTest)
		{
		    aux[nr]=copieTest%10+'0';
		    nr++;
		    copieTest/=10;
		}
		for(j=0;j<nr/2;j++)
		{
		    swapaux=aux[j];
		    aux[j]=aux[nr-j-1];
		    aux[nr-j-1]=swapaux;
		}
		aux[nr]='\0';
		strcpy(input,path);
		strcat(input,"test");
		strcat(input,aux);
		strcpy(output,path);
		strcat(output,"test");
		strcat(output,aux);
		strcat(input,".in");
		strcat(output,".out");
		
		strcpy(aux,argv[1]);
		strcat(aux,argv[2]);
		strcat(aux,".in");
		if(verify(input)) move(input,aux);
		
		strcpy(aux,"./compilator");
		strcat(aux,argv[2]);
		strcat(aux," ");
		strcat(aux,argv[1]);
		strcat(aux," ");
		strcat(aux,argv[2]);
		system(aux);
		
		time=fopen(timp,"r");
		char c = fgetc(time);
		while (c != ':') 
		{
			c = fgetc(time);
		}
		fscanf(time,"%lf",&timpexec);
		fclose(time);
		
		strcpy(aux,"Probleme/");
		strcat(aux,argv[1]);
		strcat(aux,"/");
		strcat(aux,argv[2]);
		strcat(aux,"/");
		strcat(aux,argv[1]);
		strcat(aux,argv[2]);
		strcat(aux,".out");
		
		fprintf(detalii,"Testul:%d",i);
		
		fscanf(punctaj,"%d",&nrpuncte);
		if(timpexec>timptotal)
		{
			fprintf(detalii," TIMP DEPASIT\n");
		}
		else
		{
			if(verify(output) && verify(aux) && compareFile(output,aux))
			{
				pct=pct+nrpuncte;
				fprintf(detalii," OK\n");
			}
			else
			{
				fprintf(detalii," GRESIT\n");
			}
		}
		strcpy(comanda,"rm ");
		strcat(comanda,aux);
		if(verify(aux)) system(comanda);
	}
	fprintf(detalii,"Nr puncte: %d\n",pct);
	fclose(punctaj);
	fclose(detalii);
	char aux23[100];
	sprintf(aux23,"rm %s",argv[0]);
	system(aux23);
}
