#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <sys/stat.h>
#include<sys/wait.h>
#include <unistd.h>
#include <stdlib.h>
#include <errno.h>
#include <dirent.h>
#include <stdio.h>
#include <arpa/inet.h>
#include <string.h>
#include <signal.h>
#define PORT 2728
extern int errno;
int nrprobleme=0;
void Start(int fd,int problema);
struct clas
{
	int poz;
	int id;
	int punctaj;
}clasament[100];
int nrevaluati=0;
struct asd
{
	pid_t pid;
	pid_t pidclient;
	int fd;
	int problema;
	int terminat;
}listacopii[100];
int nrcopii;
void directory(char a[])
{
	DIR* dir = opendir(a);
	if (dir) 
	{
	    closedir(dir);
	    return;
	}
	else
	{
		if (ENOENT == errno) 
		{
		     mkdir(a, 0777);
		}
	}
}
int esteNumar(char a[])
{
	int nr=0;
	int ok=1,i;
	for(i=0;i<strlen(a);i++)
	{
		if(!(a[i]>='0'&&a[i]<='9'))
		{
			ok=0;
		}
		nr=nr*10+a[i]-'0';
	}
	if(ok)
		return nr;
	return ok;
}
char * conv_addr (struct sockaddr_in address)
{
	static char str[25];
	char port[7];
	strcpy (str, inet_ntoa (address.sin_addr));
	bzero (port, 7);
	sprintf (port, ":%d", ntohs (address.sin_port));	
	strcat (str, port);
	return (str);
}
void addListOfPRoblems(char a[])
{
	FILE* fisier;
	char aux[100],aux2[100];
	int i=0;
	fisier=fopen("listaprobleme.txt","r");
	strcat(a,"\nAlegeti o problema\n");
	while (fgets(aux, 100, fisier))
	{
		nrprobleme++;
		i++;
		sprintf(aux2,"%d",i);
		strcat(a,aux2);
		strcat(a,")");
		strcat(a,aux);
    }
    fclose(fisier);
}
void adaugaproblema(char a[],int id)
{
	FILE* fisier;
	char aux[100],aux2[100];
	int i=0;
	nrprobleme=0;
	fisier=fopen("listaprobleme.txt","r");
	while (fgets(aux, 100, fisier))
	{
		nrprobleme++;
		i++;
		aux[strlen(aux)-1]='\0';
		if(i==id)
		{
			strcat(a,aux);
		}
    	}
    	fclose(fisier);
}
int run(int curent)
{
	int problema=listacopii[curent].problema;
	int id=listacopii[curent].fd;
	char path[100],aux[100];
	sprintf(path,"gcc Tester.c -o Tester%d",id);
	system(path);
	bzero(path, sizeof(path));
	sprintf(path,"./Tester%d ",id);
	adaugaproblema(path,problema);
	strcat(path," ");
	sprintf(aux,"%d",id);
	strcat(path,aux);
	system(path);
}
void creareClasament(int curent)
{
	int problema=listacopii[curent].problema;
	int id=listacopii[curent].fd;
	char aux[1000],path[100],aux2[1000];
	int i;
	FILE* fisier;
	nrevaluati++;
	clasament[nrevaluati].id=id;
	strcpy(path,"Probleme/");
	adaugaproblema(path,problema);
	strcat(path,"/utilizator");
	sprintf(aux,"%d",id);
	strcat(path,aux);
	strcat(path,"/detaliiutilizator");
	strcat(path,aux);
	strcat(path,".info");

	fisier=fopen(path,"r");
	while (fgets(aux, 999, fisier))
	{
		strcpy(aux2,aux);
	}
	strcpy(aux,aux2);
	fclose(fisier);
	int nr=0;
	for(i=0;i<strlen(aux);i++)
	{
		if(aux[i]>='0'&&aux[i]<='9')
		{
			nr=nr*10+aux[i]-'0';
		}
	}
	clasament[nrevaluati].punctaj=nr;
}
void sorteaza()
{
	int i,j,val,nr;
	struct clas aux;
	for(i=1;i<nrevaluati;i++)
	{
		for(j=i+1;j<=nrevaluati;j++)
		{
			if(clasament[i].punctaj<clasament[j].punctaj)
			{
				aux=clasament[i];
				clasament[i]=clasament[j];
				clasament[j]=aux;
			}
		}
	}
	val=-1;
	nr=0;
	for(i=1;i<=nrevaluati;i++)
	{
		if(val!=clasament[i].punctaj)
		{
			val=clasament[i].punctaj;
			nr++;
		}
		clasament[i].poz=nr;
	}
}
int main()
{
	srand(time(NULL));
	struct sockaddr_in server;
	struct sockaddr_in from;
	fd_set readfds;
	fd_set actfds;
	struct timeval tv;
	int sd, client;
	int bytes;
	int optval=1,i;
	int ruleaza=1;
	int fd;
	int problema;
	int nfds;
	pid_t pid;
	int nrclienti=0;
	int conectat[1000]={0};
	int len;
	int listaconectati[100];
	if ((sd = socket (AF_INET, SOCK_STREAM, 0)) == -1)
	{
		perror ("[server] Eroare la socket().\n");
		return errno;
	}
	setsockopt(sd, SOL_SOCKET, SO_REUSEADDR,&optval,sizeof(optval));
	bzero (&server, sizeof (server));
	server.sin_family = AF_INET;
	server.sin_addr.s_addr = htonl (INADDR_ANY);
	server.sin_port = htons (PORT);
	if (bind (sd, (struct sockaddr *) &server, sizeof (struct sockaddr)) == -1)
	{
		perror ("[server] Eroare la bind().\n");
		return errno;
	}
	if (listen (sd, 5) == -1)
	{
		perror ("[server] Eroare la listen().\n");
		return errno;
	}
	struct timeval time1;
	if(gettimeofday( &time1, 0 )) return -1;
	long cur_time1 = 1000000 * time1.tv_sec + time1.tv_usec;
	struct timeval time2;
	long cur_time2;
	double sec;
	FD_ZERO (&actfds);
	FD_SET (sd, &actfds);
	tv.tv_sec = 1;
	tv.tv_usec = 0;
	nfds = sd;
	printf ("[server] Asteptam la portul %d...\n", PORT);
	while (ruleaza)
	{
		 
		bcopy ((char *) &actfds, (char *) &readfds, sizeof (readfds));
		if (select (nfds+1, &readfds, NULL, NULL, &tv) < 0)
		{
			perror ("[server] Eroare la select().\n");
			return errno;
		}
		if (FD_ISSET (sd, &readfds))
		{
			len = sizeof (from);
			bzero (&from, sizeof (from));
			client = accept (sd, (struct sockaddr *) &from, &len);
			if (client < 0)
			{
				perror ("[server] Eroare la accept().\n");
				continue;
			}
			if (nfds < client)
				nfds = client;
			FD_SET (client, &actfds);
			nrclienti++;
			printf("[server] S-a conectat clientul cu descriptorul %d, de la adresa %s.\n",client, conv_addr (from));
			nrcopii++;
			if ((bytes = read (client, &listacopii[nrcopii].pidclient, sizeof(pid_t))) <= 0)
			{
				perror ("[client]Eroare la write() spre server.\n");
				return errno;
			}
			char auxiliar[100];
			addListOfPRoblems(auxiliar);
			problema=rand()%nrprobleme+1;

			if((pid=fork())<0)
			{
				perror("Eroare la fork()");
				return errno;
			}
			if(pid==0)
			{
				pid_t piddd = getpid();
				Start(client,problema);
				kill(piddd,SIGTERM);
				exit(2);
			}
			else
			{
				signal(SIGCHLD,SIG_IGN);
				listacopii[nrcopii].pid=pid;
				listacopii[nrcopii].fd=client;
				listacopii[nrcopii].problema=problema;
			}
		}
		if(gettimeofday( &time2, 0 )) return -1;
		cur_time2 = 1000000 * time2.tv_sec + time2.tv_usec;
		sec = (cur_time2 - cur_time1)/ 1000000.0;
		if(sec>7200.0)
		{
			ruleaza=0;
		}
	}
	char msg[100];
	printf("Start evaluare!");
	pid_t wpid,child_pid;
	int status=0;
	for(i=1;i<=nrcopii;i++)
	{
		if (0 == kill(listacopii[i].pid, 0))
		{
			printf("KILL %d\n",listacopii[i].pid);
			printf("KILL %d\n",listacopii[i].pidclient);
			kill(listacopii[i].pid,SIGKILL);
			kill(listacopii[i].pidclient,SIGKILL);
			listacopii[i].terminat=0;
			close(listacopii[i].fd);
		}
		else
		{
			listacopii[i].terminat=1;
			if ((child_pid = fork()) == 0) 
			{
				run(i);
				exit(0);
			}
		}
	}
	while ((wpid = wait(&status)) > 0);
	for(i=1;i<=nrcopii;i++)
	{
		if(listacopii[i].terminat==1)
		{
			creareClasament(i);
		}
	}
	sorteaza();
	for(i=1;i<=nrcopii;i++)
	{
		if(listacopii[i].terminat==1)
		{
			if (write (listacopii[i].fd, &nrevaluati, sizeof(int)) < 0)
			{
				perror ("[server] Eroare la write() catre client.\n");
				return -1;
			}
			if (write (listacopii[i].fd, &clasament, sizeof(clasament)) < 0)
			{
				perror ("[server] Eroare la write() catre client.\n");
				return -1;
			}
			close(listacopii[i].fd);
		}
	}
	return 0;
}
void Start(int fd,int problema)
{
	int bytes;
	int ok=1;
	char buffer[100];
	char aux[100];
	char citeste[1000];
	char msg[100];
	char cerinta[30000];
	char msgrasp[100];
	int pas=1;
	printf("A intrat in pasul 1\n");
	while(ok)
	{
		bzero(msgrasp,100);
		bzero(msg,100);
		bytes = read (fd, msg, sizeof (buffer));
		if (bytes < 0)
		{
			perror ("[ASDA]Eroare la read() de la client.\n");
			return;
		}

		msg[strlen(msg)-1]='\0';
		printf ("[server]Mesajul a fost receptionat...%s\n", msg);
		if(strcmp(msg,"Connect")==0)
		{
			strcpy(msgrasp,"Conectat cu success!");
			ok=0;
		}
		else
		{
			strcpy(msgrasp,"Va rugam sa introduceti comanda \"Connect\"");
		}
		if (write (fd, msgrasp, bytes) < 0)
		{
			perror ("[server] Eroare la write() catre client.\n");
			return;
		}
	}
	bzero(msgrasp,100);
	sprintf(aux,"%d",fd);
	if (write (fd, aux, bytes) < 0)
	{
		perror ("[server] Eroare la write() catre client.\n");
		return;
	}
	ok=1;
	bzero(msgrasp,100);
	addListOfPRoblems(msgrasp);
	if (write (fd, msgrasp, bytes) < 0)
	{
		perror ("[server] Eroare la write() catre client.\n");
		return;
	}
	bzero(msgrasp,100);
	bzero(msg,100);
	printf("A intrat in pasul 2\n");
	ok=1;
	printf("A intrat in pasul 3\n");
	bzero(msgrasp,100);
	FILE* fisier;
	strcpy(aux,"Probleme/");
	adaugaproblema(aux,problema);
	strcat(aux,"/");
	adaugaproblema(aux,problema);
	strcat(aux,".txt");
	fisier=fopen(aux,"r");
	bzero(cerinta,30000);
	bzero(aux,100);
	while (fgets(citeste, 1000, fisier))
	{
		strcat(cerinta,citeste);
    }
	fclose(fisier);
	bytes = 0;
	if ((bytes = write (fd, cerinta, 20000)) < 0)
	{
		perror ("[server] Eroare la write() catre client.\n");
		return;
	}
	printf("A intrat in pasul 4\n");
	bzero(cerinta,30000);
	if (bytes = read (fd, cerinta, 20000) < 0)
	{
		perror ("[server] Eroare la read() de la client.\n");
	}
	printf("A intrat in pasul 5\n");
	strcpy(aux,"Probleme/");
	adaugaproblema(aux,problema);
	strcat(aux,"/utilizator");
	sprintf(msg,"%d",fd);
	strcat(aux,msg);
	directory(aux);
	strcat(aux,"/");
	adaugaproblema(aux,problema);
	strcat(aux,".c");
	fisier=fopen(aux,"w");
	fprintf(fisier,"%s",cerinta);
	printf("A intrat in pasul 6\n");
	fclose(fisier);
}
