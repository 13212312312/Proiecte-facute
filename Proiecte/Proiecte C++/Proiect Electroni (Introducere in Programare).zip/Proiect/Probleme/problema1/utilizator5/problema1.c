#include <stdio.h>
int main()
{
    int x=1,nr=0;
FILE* in = fopen("problema1utilizator5.in","r");
FILE* out = fopen("problema1utilizator5.out","w");
    fscanf(in,"%d",&x);
    while(x!=0)
    {
        if(x%2==0) nr++;
        fscanf(in,"%d",&x);
    }
    fprintf(out,"%d",nr);
fclose(in);
fclose(out);
}