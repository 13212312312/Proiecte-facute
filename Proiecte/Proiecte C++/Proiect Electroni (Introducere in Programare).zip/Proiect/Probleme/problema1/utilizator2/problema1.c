#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <netdb.h>
#include <string.h>
#include <time.h>
int main()
{
	int a;
	FILE* in;
	FILE* out;
	in = fopen("problema1utilizator2.in","r");
	out = fopen("problema1utilizator2.out","w");
    int x=1,nr=0;
    fscanf(in,"%d",&x);
    while(x!=0)
    {
        if(x%2==0) nr++;
    	fscanf(in,"%d",&x);
    }
    if(nr==0) fprintf(out,"NU EXISTA"); 
    //else 
    //fprintf(out,"%d",nr);
    fclose(in);
    fclose(out);
}
